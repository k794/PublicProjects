﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1942GameApp
{
    public partial class Form1 : Form
    {
        static bool artilleryInfantryCondition = false;
        static string russiaCurrentPoints = _1942GameApp.Properties.Settings.Default.Russia;
        static string germanyCurrentPoints = _1942GameApp.Properties.Settings.Default.Germany;
        static string ukCurrentPoints = _1942GameApp.Properties.Settings.Default.UK;
        static string japanCurrentPoints = _1942GameApp.Properties.Settings.Default.Japan;
        static string usCurrentPoints = _1942GameApp.Properties.Settings.Default.US;
        static int RPoints, Gpoints, UkPoints, JPoints, UsPoints;
        static string loadedFile = "";
        static string savedFile = "";
        static string selected = "";
        static string country = "";
        static string[] AttackingUnits = { "Infantry: ", "Artillery: ", "Tanks: ", "AA: ", "Fighter: ", "Bomber: ", "Sub: ", "Destroyer: ", "Cruiser: ", "Carrier: ", "Battleship: " };
        static string[] DefendingUnits = { "Infantry: ", "Artillery: ", "Tanks: ", "AA: ", "Fighter: ", "Bomber: ", "Sub: ", "Destroyer: ", "Cruiser: ", "Carrier: ", "Battleship: " };
        static int[] DefaultAttackingStrength = { 1, 2, 3, 0, 3, 4, 2, 2, 3, 1, 4 };
        static int[] DefaultDefendingStrength = { 2, 2, 3, 1, 4, 1, 1, 2, 3, 2, 4 };
        static int[] AttackingStrength = new int[11];
        static int[] DefendingStrength = new int[11];
        static int[] AttackingUnitsCount = new int[11];
        static int[] DefendingUnitsCount = new int[11];
        List<TextBox> myTextboxList = new List<TextBox>();
        List<TextBox> attackValues = new List<TextBox>();
        List<TextBox> defenseValues = new List<TextBox>();


        public Form1()
        {
            InitializeComponent();

            myTextboxList.Add(textBox1);
            myTextboxList.Add(textBox2);
            myTextboxList.Add(textBox3);
            myTextboxList.Add(textBox4);
            myTextboxList.Add(textBox5);
            myTextboxList.Add(textBox6);
            myTextboxList.Add(textBox7);
            myTextboxList.Add(textBox8);
            myTextboxList.Add(textBox9);
            myTextboxList.Add(textBox10);
            myTextboxList.Add(textBox11);
            myTextboxList.Add(textBox12);
            myTextboxList.Add(textBox13);
            myTextboxList.Add(textBox14);
            myTextboxList.Add(textBox15);
            myTextboxList.Add(textBox16);
            myTextboxList.Add(textBox17);
            myTextboxList.Add(textBox18);
            myTextboxList.Add(textBox19);
            myTextboxList.Add(textBox20);
            myTextboxList.Add(textBox21);
            myTextboxList.Add(textBox22);
            myTextboxList.Add(textBox23);
            myTextboxList.Add(textBox24);
            myTextboxList.Add(textBox25);
            myTextboxList.Add(textBox26);
            myTextboxList.Add(textBox27);
            myTextboxList.Add(textBox28);
            myTextboxList.Add(textBox29);
            myTextboxList.Add(textBox30);
            myTextboxList.Add(textBox31);
            myTextboxList.Add(textBox32);
            myTextboxList.Add(textBox33);
            myTextboxList.Add(textBox34);
            myTextboxList.Add(textBox35);
            myTextboxList.Add(textBox36);
            myTextboxList.Add(textBox37);
            myTextboxList.Add(textBox38);
            myTextboxList.Add(textBox39);
            myTextboxList.Add(textBox40);
            myTextboxList.Add(textBox41);
            myTextboxList.Add(textBox42);
            myTextboxList.Add(textBox43);
            myTextboxList.Add(textBox44);

            attackValues.Add(attackBox1);
            attackValues.Add(attackBox2);
            attackValues.Add(attackBox3);
            attackValues.Add(attackBox4);
            attackValues.Add(attackBox5);
            attackValues.Add(attackBox6);
            attackValues.Add(attackBox7);
            attackValues.Add(attackBox8);
            attackValues.Add(attackBox9);
            attackValues.Add(attackBox10);
            attackValues.Add(attackBox11);

            defenseValues.Add(defenseBox1);
            defenseValues.Add(defenseBox2);
            defenseValues.Add(defenseBox3);
            defenseValues.Add(defenseBox4);
            defenseValues.Add(defenseBox5);
            defenseValues.Add(defenseBox6);
            defenseValues.Add(defenseBox7);
            defenseValues.Add(defenseBox8);
            defenseValues.Add(defenseBox9);
            defenseValues.Add(defenseBox10);
            defenseValues.Add(defenseBox11);

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            ChangeLogger.AppendText("Game Loaded\n");
            dataGridView1.Rows.Add(1);
            dataGridView1.Rows[0].ReadOnly = true; // Makes the first row of the point system read only
            dataGridView1.Rows[0].DefaultCellStyle.BackColor = Color.LightSteelBlue;

            RPoints = int.Parse(russiaCurrentPoints);
            Gpoints = int.Parse(germanyCurrentPoints);
            UkPoints = int.Parse(ukCurrentPoints);
            JPoints = int.Parse(japanCurrentPoints);
            UsPoints = int.Parse(usCurrentPoints);

            for (int i = 0; i < 11; i++)
            {
                attackValues[i].Text = DefaultAttackingStrength[i].ToString();
                defenseValues[i].Text = DefaultDefendingStrength[i].ToString();
                AttackingStrength[i] = DefaultAttackingStrength[i];
                DefendingStrength[i] = DefaultDefendingStrength[i];
            }
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            bool condition = true; // Run condition for bad input

            for (int col = 0; col < dataGridView1.ColumnCount; col++) // Manages the point system
            {
                dataGridView1.Rows[0].Cells[col].Value = 0; // Resets the sum on each key change to prevent duplicate adding
                for (int row = 1; row < dataGridView1.Rows.Count; row++)
                {
                    string input = "";
                    int value;

                    if (row % 2 == 1) //Alter color to make + / - turns visible
                    {
                        dataGridView1.Rows[row].DefaultCellStyle.BackColor = Color.LightSeaGreen;
                    }
                    else
                    {
                        dataGridView1.Rows[row].DefaultCellStyle.BackColor = Color.LightCoral;
                    }

                    if (dataGridView1.Rows[row].Cells[col].Value != null) // Defaults values to 0 if no input
                    {
                        input = dataGridView1.Rows[row].Cells[col].Value.ToString();
                    }
                    else
                    {
                        input = "";
                    }

                    if (!int.TryParse(input, out value) && input != "") // Checks for bad input
                    {
                        ChangeLogger.AppendText(String.Format("Invalid input at cell: ({0}, {1})\n", col + 1, row + 1));
                        input = "0";
                        dataGridView1.Rows[row].Cells[col].Value = "0";
                        condition = false;
                    }
                    else
                    {
                        if(dataGridView1.Rows[row].DefaultCellStyle.BackColor == Color.LightCoral)
                        {
                            dataGridView1.Rows[0].Cells[col].Value = Convert.ToInt64(dataGridView1.Rows[0].Cells[col].Value) + Convert.ToInt64(dataGridView1.Rows[row].Cells[col].Value)*-1;
                        }
                        else
                        {
                            dataGridView1.Rows[0].Cells[col].Value = Convert.ToInt64(dataGridView1.Rows[0].Cells[col].Value) + Convert.ToInt64(dataGridView1.Rows[row].Cells[col].Value);
                        }
                        
                    }
                }
            }



            if (condition == true && dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor == Color.LightSeaGreen) //Change log for each point gain/loss
            {
                selected = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].FormattedValue.ToString();
                country = dataGridView1.Columns[e.ColumnIndex].HeaderText + ": ";
                ChangeLogger.AppendText(country + selected + "\n");
            }
            if (condition == true && dataGridView1.Rows[e.RowIndex].DefaultCellStyle.BackColor == Color.LightCoral)
            {
                selected = dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].FormattedValue.ToString();
                country = dataGridView1.Columns[e.ColumnIndex].HeaderText + ": ";
                ChangeLogger.AppendText(country + "-" + selected + "\n");
            }
        }

        private void button1_Click(object sender, EventArgs e) 
        {
            AttackerTextBox.Clear();
            DefenderTextBox.Clear();
            int totalAttackerAttempts = 0;
            int totalDefenderAttempts = 0;
            int totalAttackHits = 0;
            int totalDefendHits = 0;
            int attackerHitIndex = 21;
            int defenderHitIndex = 32;
            bool runCondition = true; //Condition for bad input

            Random r = new Random();

            //Attacker code

            for ( var i = 0; i < 11; i++)
            {
                int additionalInfantry = 0;
                if (myTextboxList[i].Text == "") //Sets empty cells to 0 if no value is entered
                {
                    myTextboxList[i].Text = "0";
                }

                if (!int.TryParse(myTextboxList[i].Text, out int count))//Validates input
                {
                    runCondition = false;
                    myTextboxList[i].Text = "";
                    AttackerLog.AppendText("Invalid Input");
                }

                if (artilleryInfantryCondition == true && runCondition == true && i == 0)
                {
                    int inf = int.Parse(myTextboxList[0].Text);
                    int art = int.Parse(myTextboxList[1].Text);
                    int minValue = Math.Min(art * 2, inf);
                    additionalInfantry = minValue;
                    count = count + additionalInfantry;
                }

                if (runCondition == true) //Write results
                {
                    AttackerTextBox.AppendText(AttackingUnits[i]);
                    AttackerLog.AppendText(AttackingUnits[i]);
                }

                int hits = 0;
                while (count > 0 && runCondition == true) //Generates the random numbers
                {
                    int random = r.Next(1, 7);


                    AttackerLog.AppendText(random + " ");
                    if (random <= AttackingStrength[i])
                    {
                        AttackerTextBox.AppendText(random + " ", Color.Cyan);
                        hits++;
                    }
                    else
                    {
                        AttackerTextBox.AppendText(random + " ", Color.Black);
                    }
                    count--;
                    totalAttackerAttempts++;
                    
                }
                totalAttackHits = totalAttackHits + hits;
                AttackerTextBox.AppendText("\n");
                AttackerLog.AppendText("\n");
                AttackerHits.Text = totalAttackHits.ToString();
                myTextboxList[attackerHitIndex].Text = hits.ToString();
                attackerHitIndex--;
            }
            AttackerMisses.Text = (totalAttackerAttempts - totalAttackHits).ToString();
            AttackerLog.AppendText("Total Hits: " + AttackerHits.Text);
            AttackerTextBox.AppendText("-------------------------------------------------------------------------\n");
            AttackerLog.AppendText("\n---------------------------------------------\n");


            //Defender code
            int index = 0;
            for (var i = 43; i > 32; i--) // Had to start index in a weird position due to unusual list. Can be fixed later.
            {
                if (myTextboxList[i].Text == "")
                {
                    myTextboxList[i].Text = "0";
                }

                if (!int.TryParse(myTextboxList[i].Text, out int count))
                {
                    runCondition = false;
                    myTextboxList[i].Text = "";
                    DefenderLog.AppendText("Invalid Input");
                }

                if (runCondition == true)
                {
                    DefenderTextBox.AppendText(DefendingUnits[index]);
                    DefenderLog.AppendText(DefendingUnits[index]);
                }

                int hits = 0;
                while (count > 0 && runCondition == true)
                {
                    int random = r.Next(1, 7);

                    DefenderLog.AppendText(random + " ");
                    if (random <= DefendingStrength[index])
                    {
                        DefenderTextBox.AppendText(random + " ", Color.Yellow);
                        hits++;
                    }
                    else
                    {
                        DefenderTextBox.AppendText(random + " ", Color.Black);
                    }
                    count--;
                    totalDefenderAttempts++;

                }
                totalDefendHits = totalDefendHits + hits;
                DefenderTextBox.AppendText("\n");
                DefenderLog.AppendText("\n");
                DefenderHits.Text = totalDefendHits.ToString();
                myTextboxList[defenderHitIndex].Text = hits.ToString();
                defenderHitIndex--;
                index++;
            }
            DefenderMisses.Text = (totalDefenderAttempts - totalDefendHits).ToString();
            DefenderLog.AppendText("Total Hits: " + DefenderHits.Text);
            DefenderTextBox.AppendText("-------------------------------------------------------------------------\n");
            DefenderLog.AppendText("\n---------------------------------------------\n");

            if (runCondition == false)
            {
                AttackerTextBox.Clear();
                AttackerTextBox.AppendText("Invalid Input");

                DefenderTextBox.Clear();
                DefenderTextBox.AppendText("Invalid Input");
            }
        }

        private void AAButton_Click(object sender, EventArgs e)
        {
            bool runCondition = true;

            if (AACount.Text == "")
            {
                AACount.Text = "0";
            }
            if (!int.TryParse(AACount.Text, out int AA))
            {
                runCondition = false;
                AATextBox.AppendText("Invalid Input\n");
            }

            if (HostilePlanes.Text == "")
            {
                HostilePlanes.Text = "0";
            }
            if (!int.TryParse(HostilePlanes.Text, out int planes) && runCondition == true)
            {
                runCondition = false;
                AATextBox.AppendText("Invalid Input\n");
            }

            if (runCondition == true)
            {
                Random r = new Random();
                int attempts = AA * 3;
                int actual = Math.Min(attempts, planes);
                int hits = 0;

                for (int i = 0; actual > i; i++)
                {
                    int random = r.Next(1, 7);
                    
                    if (random == 1)
                    {
                        hits++;
                        AATextBox.AppendText(random + " ", Color.DarkBlue);
                    }
                    else
                    {
                        AATextBox.AppendText(random + " ", Color.Black);
                    }
                }
                AAHits.Text = hits.ToString();
                AATextBox.AppendText("\n");
            }
            AATextBox.AppendText("-----------------------------------------\n");
        }

        private void OffShoreButton_Click(object sender, EventArgs e)
        {
            bool runCondition = true;

            if (CruisersCount.Text == "")
            {
                CruisersCount.Text = "0";
            }
            if (!int.TryParse(CruisersCount.Text, out int cruisers))
            {
                runCondition = false;
                OffShoreBox.AppendText("Invalid Input\n");
            }

            if (BattleshipCount.Text == "")
            {
                BattleshipCount.Text = "0";
            }
            if (!int.TryParse(BattleshipCount.Text, out int battleships) && runCondition == true)
            {
                runCondition = false;
                OffShoreBox.AppendText("Invalid Input\n");
            }

            if (runCondition == true)
            {
                Random r = new Random();
                int hits = 0;

                OffShoreBox.AppendText("Cruiser hits: ");
                for (int i = 0; cruisers > i; i++)
                {
                    int random = r.Next(1, 7);
                    if (random <= 3)
                    {
                        hits++;
                        OffShoreBox.AppendText(random + " ", Color.DarkBlue);
                    }
                    else
                    {
                        OffShoreBox.AppendText(random + " ", Color.Black);
                    }
                }
                OffShoreBox.AppendText("\n");

                OffShoreBox.AppendText("Battleship hits: ");
                for (int i = 0; battleships > i; i++)
                {
                    int random = r.Next(1, 7);
                    if (random <= 4)
                    {
                        hits++;
                        OffShoreBox.AppendText(random + " ", Color.DarkBlue);
                    }
                    else
                    {
                        OffShoreBox.AppendText(random + " ", Color.Black);
                    }
                }
                OffShoreBox.AppendText("\n");
                OffShoreHits.Text = hits.ToString();
            }
            OffShoreBox.AppendText("-----------------------------------------\n");
        }

        private void BombingButton_Click(object sender, EventArgs e)
        {
            bool runCondition = true;
            
            if (BomberCount.Text == "")
            {
                BomberCount.Text = "0";
            }
            if (!int.TryParse(BomberCount.Text, out int bombers))
            {
                runCondition = false;
                BombingBox.AppendText("Invalid Input\n");
            }

            if (EscortCount.Text == "")
            {
                EscortCount.Text = "0";
            }
            if (!int.TryParse(EscortCount.Text, out int escorts) && runCondition == true)
            {
                runCondition = false;
                BombingBox.AppendText("Invalid Input\n");
            }

            if (InterceptorCount.Text == "")
            {
                InterceptorCount.Text = "0";
            }
            if (!int.TryParse(InterceptorCount.Text, out int interceptors) && runCondition == true)
            {
                runCondition = false;
                BombingBox.AppendText("Invalid Input\n");
            }

            if (runCondition == true)
            {
                Random r = new Random();
                int defendHits = 0;
                int attackHits = 0;

                BombingBox.AppendText("Interceptor hits: ");
                for (int i = 0; interceptors > i; i++)
                {
                    int random = r.Next(1, 7);
                    if (random <= 3)
                    {
                        attackHits++;
                        BombingBox.AppendText(random + " ", Color.DarkBlue);
                    }
                    else
                    {
                        BombingBox.AppendText(random + " ", Color.Black);
                    }
                }
                BombingBox.AppendText("\n");

                while ( (attackHits > 0) && escorts > 0)
                {
                    escorts--;
                    attackHits--;
                }
                while ( (attackHits > 0) && bombers > 0)
                {
                    bombers--;
                    attackHits--;
                }

                if (escorts > 0 && interceptors > 0)
                {
                    BombingBox.AppendText("Escorts left: " + escorts + "\n");
                    BombingBox.AppendText("\nEscort hits: ");
                    for (int i = 0; escorts > i; i++)
                    {
                        int random = r.Next(1, 7);
                        if (random <= 2)
                        {
                            defendHits++;
                            BombingBox.AppendText(random + " ", Color.DarkBlue);
                        }
                        else
                        {
                            BombingBox.AppendText(random + " ", Color.Black);
                        }
                    }
                    BombingBox.AppendText("\nDefender Hits: " + defendHits + "\n");
                    
                }
                else
                {
                    BombingBox.AppendText("No available escorts\n");
                }
                
                if (bombers > 0)
                {
                    BombingBox.AppendText("Surviving bombers: " + bombers + "\n");
                }
                else
                {
                    BombingBox.AppendText("All bombers destroyed!\n");
                }
            }
            BombingBox.AppendText("---------------------------------\n");
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (ArtInfCheckBox.Checked == true)
            {
                GameLog.AppendText("Artillery / Infantry Pairing Enabled\n");
                artilleryInfantryCondition = true;
            }
            else
            {
                GameLog.AppendText("Artillery / Infantry Pairing Enabled\n");
                artilleryInfantryCondition = false;
            }
        }

        private void ArtInfHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This setting enables a buff to artillery.\nFor each artillery, up to two infantry get an additional roll on 1. If there are more artillery than infantry, the infantry do not get to exceed twice their count in rolls.\n\n\nExample: 4 artillery, 3 infantry results in 4 rolls for artillery, 6 rolls for infantry.", "Rule", MessageBoxButtons.OK);
        }

        private void LoadFile_Click_1(object sender, EventArgs e)
        {
            System.Windows.Forms.OpenFileDialog FD = new System.Windows.Forms.OpenFileDialog();

            FD.ShowDialog();
            loadedFile = FD.FileName;
            FileBox.Text = FD.FileName;
        }

        private void CreateNewFile_Click_1(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd1 = new FolderBrowserDialog();

            fbd1.ShowDialog();
            savedFile = fbd1.SelectedPath;
            NewFileBox.Text = fbd1.SelectedPath;
        }

        //Reset buttons for the special event battles
        private void AAReset_Click(object sender, EventArgs e)
        {
            AACount.Text = "";
            AAHits.Text = "";
            AATextBox.Text = "";
            HostilePlanes.Text = "";
        }

        private void OffShoreReset_Click(object sender, EventArgs e)
        {
            OffShoreBox.Text = "";
            OffShoreHits.Text = "";
            BattleshipCount.Text = "";
            CruisersCount.Text = "";
        }

        private void BombingReset_Click(object sender, EventArgs e)
        {
            BomberCount.Text = "";
            BombingBox.Text = "";
            EscortCount.Text = "";
            InterceptorCount.Text = "";
        }

        private void CustomReset_Click(object sender, EventArgs e)
        {
            CustomBox.Text = "";
            CustomHits.Text = "";
            CustomStrength.Text  = "";
            CustomUnitCount.Text = "";
        }

        //Handles bad header click
        private void dataGridView1_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int rowIndex = e.RowIndex;
            Notes.AppendText("Bad Click\n");

        } 

        //These five events handle the changing of the IPC text boxes
        //to ensure the data is valid, and resets to previous count if it is invalid
        private void textBox45_Leave(object sender, EventArgs e)
        {
            if (!int.TryParse(RussiaIPC.Text, out int newPoints))
            {
                Notes.AppendText("Bad input for Russia points\n");
                RussiaIPC.Text = RPoints.ToString();
            }
            else
            {
                int change = newPoints - RPoints;
                if (change != 0)
                {
                    Notes.AppendText("Russia: " + change + "\n");
                }
                RPoints = newPoints;
            }
        }

        private void textBox46_Leave(object sender, EventArgs e)
        {
            if (!int.TryParse(GermanyIPC.Text, out int newPoints))
            {
                Notes.AppendText("Bad input for Germany points\n");
                GermanyIPC.Text = Gpoints.ToString();
            }
            else
            {
                int change = newPoints - Gpoints;
                if  (change != 0)
                {
                    Notes.AppendText("Germany: " + change + "\n");
                }

                Gpoints = newPoints;
            }
        }

        private void textBox47_Leave(object sender, EventArgs e)
        {
            if (!int.TryParse(UKIPC.Text, out int newPoints))
            {
                Notes.AppendText("Bad input for UK points\n");
                UKIPC.Text = UkPoints.ToString();
            }
            else
            {
                int change = newPoints - UkPoints;
                if (change != 0)
                {
                    Notes.AppendText("UK: " + change + "\n");
                }

                UkPoints = newPoints;
            }
        }

        private void textBox48_Leave(object sender, EventArgs e)
        {
            if (!int.TryParse(JapanIPC.Text, out int newPoints))
            {
                Notes.AppendText("Bad input for Japan points\n");
                JapanIPC.Text = JPoints.ToString();
            }
            else
            {
                int change = newPoints - JPoints;
                if (change != 0)
                {
                    Notes.AppendText("Japan: " + change + "\n");
                }

                JPoints = newPoints;
            }
        }

        private void textBox49_Leave(object sender, EventArgs e)
        {
            if (!int.TryParse(USIPC.Text, out int newPoints))
            {
                Notes.AppendText("Bad input for US points\n");
                USIPC.Text = UsPoints.ToString();
            }
            else
            {
                int change = newPoints - UsPoints;
                if (change != 0)
                {
                    Notes.AppendText("US: " + change + "\n");
                }

                UsPoints = newPoints;
            }
        }
    }

    //Extension of the TextBox method to allow for changing the color of each individual char
    public static class RichTextBoxExtensions
    {
        public static void AppendText(this RichTextBox box, string text, Color color)
        {
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;

            box.SelectionColor = color;
            box.AppendText(text);
            box.SelectionColor = box.ForeColor;
        }
    }
}

