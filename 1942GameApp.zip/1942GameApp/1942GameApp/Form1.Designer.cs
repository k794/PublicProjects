﻿namespace _1942GameApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.FightButton = new System.Windows.Forms.Button();
            this.DefenderSpecialConditions = new System.Windows.Forms.RichTextBox();
            this.AttackerSpecialConditions = new System.Windows.Forms.RichTextBox();
            this.DefenderTextBox = new System.Windows.Forms.RichTextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.DefenderMisses = new System.Windows.Forms.TextBox();
            this.DefenderHits = new System.Windows.Forms.TextBox();
            this.AttackerMisses = new System.Windows.Forms.TextBox();
            this.AttackerHits = new System.Windows.Forms.TextBox();
            this.AttackerTextBox = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.USIPC = new System.Windows.Forms.TextBox();
            this.JapanIPC = new System.Windows.Forms.TextBox();
            this.UKIPC = new System.Windows.Forms.TextBox();
            this.GermanyIPC = new System.Windows.Forms.TextBox();
            this.RussiaIPC = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.Notes = new System.Windows.Forms.RichTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.ChangeLogger = new System.Windows.Forms.RichTextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Russia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Germany = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UK = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Japan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.US = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.panel7 = new System.Windows.Forms.Panel();
            this.CustomReset = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label63 = new System.Windows.Forms.Label();
            this.CustomBox = new System.Windows.Forms.RichTextBox();
            this.CustomHits = new System.Windows.Forms.TextBox();
            this.CustomStrength = new System.Windows.Forms.TextBox();
            this.CustomUnitCount = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BombingReset = new System.Windows.Forms.Button();
            this.BombingButton = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.BombingBox = new System.Windows.Forms.RichTextBox();
            this.InterceptorCount = new System.Windows.Forms.TextBox();
            this.EscortCount = new System.Windows.Forms.TextBox();
            this.BomberCount = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.OffShoreReset = new System.Windows.Forms.Button();
            this.OffShoreButton = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.OffShoreBox = new System.Windows.Forms.RichTextBox();
            this.OffShoreHits = new System.Windows.Forms.TextBox();
            this.BattleshipCount = new System.Windows.Forms.TextBox();
            this.CruisersCount = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.AAReset = new System.Windows.Forms.Button();
            this.AAButton = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.AATextBox = new System.Windows.Forms.RichTextBox();
            this.AAHits = new System.Windows.Forms.TextBox();
            this.HostilePlanes = new System.Windows.Forms.TextBox();
            this.AACount = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label49 = new System.Windows.Forms.Label();
            this.GameLog = new System.Windows.Forms.RichTextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.DefenderLog = new System.Windows.Forms.RichTextBox();
            this.AttackerLog = new System.Windows.Forms.RichTextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label62 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.defenseBox11 = new System.Windows.Forms.TextBox();
            this.defenseBox10 = new System.Windows.Forms.TextBox();
            this.defenseBox9 = new System.Windows.Forms.TextBox();
            this.defenseBox8 = new System.Windows.Forms.TextBox();
            this.defenseBox7 = new System.Windows.Forms.TextBox();
            this.defenseBox6 = new System.Windows.Forms.TextBox();
            this.defenseBox5 = new System.Windows.Forms.TextBox();
            this.defenseBox4 = new System.Windows.Forms.TextBox();
            this.defenseBox3 = new System.Windows.Forms.TextBox();
            this.defenseBox2 = new System.Windows.Forms.TextBox();
            this.defenseBox1 = new System.Windows.Forms.TextBox();
            this.attackBox11 = new System.Windows.Forms.TextBox();
            this.attackBox10 = new System.Windows.Forms.TextBox();
            this.attackBox9 = new System.Windows.Forms.TextBox();
            this.attackBox8 = new System.Windows.Forms.TextBox();
            this.attackBox7 = new System.Windows.Forms.TextBox();
            this.attackBox6 = new System.Windows.Forms.TextBox();
            this.attackBox5 = new System.Windows.Forms.TextBox();
            this.attackBox4 = new System.Windows.Forms.TextBox();
            this.attackBox3 = new System.Windows.Forms.TextBox();
            this.attackBox2 = new System.Windows.Forms.TextBox();
            this.attackBox1 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.ArtInfHelp = new System.Windows.Forms.Button();
            this.ArtInfCheckBox = new System.Windows.Forms.CheckBox();
            this.NewFileBox = new System.Windows.Forms.TextBox();
            this.FileBox = new System.Windows.Forms.TextBox();
            this.CreateNewFile = new System.Windows.Forms.Button();
            this.LoadFile = new System.Windows.Forms.Button();
            this.tabPage1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.tabPage1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage1.Controls.Add(this.FightButton);
            this.tabPage1.Controls.Add(this.DefenderSpecialConditions);
            this.tabPage1.Controls.Add(this.AttackerSpecialConditions);
            this.tabPage1.Controls.Add(this.DefenderTextBox);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.DefenderMisses);
            this.tabPage1.Controls.Add(this.DefenderHits);
            this.tabPage1.Controls.Add(this.AttackerMisses);
            this.tabPage1.Controls.Add(this.AttackerHits);
            this.tabPage1.Controls.Add(this.AttackerTextBox);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.panel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(768, 423);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Battle Phase";
            // 
            // FightButton
            // 
            this.FightButton.Location = new System.Drawing.Point(150, 392);
            this.FightButton.Name = "FightButton";
            this.FightButton.Size = new System.Drawing.Size(75, 23);
            this.FightButton.TabIndex = 158;
            this.FightButton.Text = "FIGHT!";
            this.FightButton.UseVisualStyleBackColor = true;
            this.FightButton.Click += new System.EventHandler(this.button1_Click);
            // 
            // DefenderSpecialConditions
            // 
            this.DefenderSpecialConditions.BackColor = System.Drawing.SystemColors.Info;
            this.DefenderSpecialConditions.Location = new System.Drawing.Point(399, 278);
            this.DefenderSpecialConditions.Name = "DefenderSpecialConditions";
            this.DefenderSpecialConditions.Size = new System.Drawing.Size(111, 104);
            this.DefenderSpecialConditions.TabIndex = 157;
            this.DefenderSpecialConditions.Text = "";
            // 
            // AttackerSpecialConditions
            // 
            this.AttackerSpecialConditions.BackColor = System.Drawing.SystemColors.Info;
            this.AttackerSpecialConditions.Location = new System.Drawing.Point(399, 91);
            this.AttackerSpecialConditions.Name = "AttackerSpecialConditions";
            this.AttackerSpecialConditions.Size = new System.Drawing.Size(111, 104);
            this.AttackerSpecialConditions.TabIndex = 156;
            this.AttackerSpecialConditions.Text = "";
            // 
            // DefenderTextBox
            // 
            this.DefenderTextBox.BackColor = System.Drawing.Color.Goldenrod;
            this.DefenderTextBox.Location = new System.Drawing.Point(516, 204);
            this.DefenderTextBox.Name = "DefenderTextBox";
            this.DefenderTextBox.Size = new System.Drawing.Size(244, 178);
            this.DefenderTextBox.TabIndex = 155;
            this.DefenderTextBox.Text = "";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(401, 242);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(39, 13);
            this.label19.TabIndex = 154;
            this.label19.Text = "Misses";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(401, 212);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 13);
            this.label18.TabIndex = 153;
            this.label18.Text = "Defender Hits";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(401, 57);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(39, 13);
            this.label17.TabIndex = 152;
            this.label17.Text = "Misses";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(401, 27);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 13);
            this.label16.TabIndex = 151;
            this.label16.Text = "Attacker Hits";
            // 
            // DefenderMisses
            // 
            this.DefenderMisses.Location = new System.Drawing.Point(475, 239);
            this.DefenderMisses.Name = "DefenderMisses";
            this.DefenderMisses.Size = new System.Drawing.Size(35, 20);
            this.DefenderMisses.TabIndex = 150;
            // 
            // DefenderHits
            // 
            this.DefenderHits.Location = new System.Drawing.Point(475, 209);
            this.DefenderHits.Name = "DefenderHits";
            this.DefenderHits.Size = new System.Drawing.Size(35, 20);
            this.DefenderHits.TabIndex = 149;
            // 
            // AttackerMisses
            // 
            this.AttackerMisses.Location = new System.Drawing.Point(475, 54);
            this.AttackerMisses.Name = "AttackerMisses";
            this.AttackerMisses.Size = new System.Drawing.Size(35, 20);
            this.AttackerMisses.TabIndex = 148;
            // 
            // AttackerHits
            // 
            this.AttackerHits.Location = new System.Drawing.Point(475, 24);
            this.AttackerHits.Name = "AttackerHits";
            this.AttackerHits.Size = new System.Drawing.Size(35, 20);
            this.AttackerHits.TabIndex = 147;
            // 
            // AttackerTextBox
            // 
            this.AttackerTextBox.BackColor = System.Drawing.Color.DarkCyan;
            this.AttackerTextBox.Location = new System.Drawing.Point(516, 17);
            this.AttackerTextBox.Name = "AttackerTextBox";
            this.AttackerTextBox.Size = new System.Drawing.Size(244, 178);
            this.AttackerTextBox.TabIndex = 146;
            this.AttackerTextBox.Text = "";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Goldenrod;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.textBox23);
            this.panel2.Controls.Add(this.textBox24);
            this.panel2.Controls.Add(this.textBox25);
            this.panel2.Controls.Add(this.textBox26);
            this.panel2.Controls.Add(this.textBox27);
            this.panel2.Controls.Add(this.textBox28);
            this.panel2.Controls.Add(this.textBox29);
            this.panel2.Controls.Add(this.textBox30);
            this.panel2.Controls.Add(this.textBox31);
            this.panel2.Controls.Add(this.textBox32);
            this.panel2.Controls.Add(this.textBox33);
            this.panel2.Controls.Add(this.textBox34);
            this.panel2.Controls.Add(this.textBox35);
            this.panel2.Controls.Add(this.textBox36);
            this.panel2.Controls.Add(this.textBox37);
            this.panel2.Controls.Add(this.textBox38);
            this.panel2.Controls.Add(this.textBox39);
            this.panel2.Controls.Add(this.textBox40);
            this.panel2.Controls.Add(this.textBox41);
            this.panel2.Controls.Add(this.textBox42);
            this.panel2.Controls.Add(this.textBox43);
            this.panel2.Controls.Add(this.textBox44);
            this.panel2.Controls.Add(this.label38);
            this.panel2.Controls.Add(this.label39);
            this.panel2.Controls.Add(this.label40);
            this.panel2.Controls.Add(this.label41);
            this.panel2.Controls.Add(this.label42);
            this.panel2.Controls.Add(this.label43);
            this.panel2.Controls.Add(this.label44);
            this.panel2.Controls.Add(this.label45);
            this.panel2.Controls.Add(this.label46);
            this.panel2.Controls.Add(this.label47);
            this.panel2.Controls.Add(this.label48);
            this.panel2.Location = new System.Drawing.Point(197, 17);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(185, 365);
            this.panel2.TabIndex = 145;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(132, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(25, 13);
            this.label15.TabIndex = 143;
            this.label15.Text = "Hits";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(69, 9);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(31, 13);
            this.label14.TabIndex = 142;
            this.label14.Text = "Units";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(6, 9);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(56, 13);
            this.label25.TabIndex = 94;
            this.label25.Text = "Defenders";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(124, 337);
            this.textBox23.Name = "textBox23";
            this.textBox23.ReadOnly = true;
            this.textBox23.Size = new System.Drawing.Size(40, 20);
            this.textBox23.TabIndex = 139;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(124, 307);
            this.textBox24.Name = "textBox24";
            this.textBox24.ReadOnly = true;
            this.textBox24.Size = new System.Drawing.Size(40, 20);
            this.textBox24.TabIndex = 138;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(124, 277);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(40, 20);
            this.textBox25.TabIndex = 137;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(124, 247);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(40, 20);
            this.textBox26.TabIndex = 136;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(124, 217);
            this.textBox27.Name = "textBox27";
            this.textBox27.ReadOnly = true;
            this.textBox27.Size = new System.Drawing.Size(40, 20);
            this.textBox27.TabIndex = 135;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(124, 187);
            this.textBox28.Name = "textBox28";
            this.textBox28.ReadOnly = true;
            this.textBox28.Size = new System.Drawing.Size(40, 20);
            this.textBox28.TabIndex = 134;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(124, 157);
            this.textBox29.Name = "textBox29";
            this.textBox29.ReadOnly = true;
            this.textBox29.Size = new System.Drawing.Size(40, 20);
            this.textBox29.TabIndex = 133;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(124, 127);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(40, 20);
            this.textBox30.TabIndex = 132;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(124, 97);
            this.textBox31.Name = "textBox31";
            this.textBox31.ReadOnly = true;
            this.textBox31.Size = new System.Drawing.Size(40, 20);
            this.textBox31.TabIndex = 131;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(124, 67);
            this.textBox32.Name = "textBox32";
            this.textBox32.ReadOnly = true;
            this.textBox32.Size = new System.Drawing.Size(40, 20);
            this.textBox32.TabIndex = 130;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(124, 37);
            this.textBox33.Name = "textBox33";
            this.textBox33.ReadOnly = true;
            this.textBox33.Size = new System.Drawing.Size(40, 20);
            this.textBox33.TabIndex = 129;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(64, 337);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(40, 20);
            this.textBox34.TabIndex = 117;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(64, 307);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(40, 20);
            this.textBox35.TabIndex = 116;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(64, 277);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(40, 20);
            this.textBox36.TabIndex = 115;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(64, 247);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(40, 20);
            this.textBox37.TabIndex = 114;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(64, 217);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(40, 20);
            this.textBox38.TabIndex = 113;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(64, 187);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(40, 20);
            this.textBox39.TabIndex = 112;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(64, 157);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(40, 20);
            this.textBox40.TabIndex = 111;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(64, 127);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(40, 20);
            this.textBox41.TabIndex = 110;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(64, 97);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(40, 20);
            this.textBox42.TabIndex = 109;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(64, 67);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(40, 20);
            this.textBox43.TabIndex = 108;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(64, 37);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(40, 20);
            this.textBox44.TabIndex = 107;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(6, 340);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(53, 13);
            this.label38.TabIndex = 106;
            this.label38.Text = "Battleship";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(6, 310);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(37, 13);
            this.label39.TabIndex = 105;
            this.label39.Text = "Carrier";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(6, 280);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(39, 13);
            this.label40.TabIndex = 104;
            this.label40.Text = "Cruiser";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(6, 250);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(52, 13);
            this.label41.TabIndex = 103;
            this.label41.Text = "Destroyer";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(6, 220);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(26, 13);
            this.label42.TabIndex = 102;
            this.label42.Text = "Sub";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(6, 190);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(43, 13);
            this.label43.TabIndex = 101;
            this.label43.Text = "Bomber";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(6, 160);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(39, 13);
            this.label44.TabIndex = 100;
            this.label44.Text = "Fighter";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 130);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(21, 13);
            this.label45.TabIndex = 99;
            this.label45.Text = "AA";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(6, 100);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(37, 13);
            this.label46.TabIndex = 98;
            this.label46.Text = "Tanks";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(6, 70);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(40, 13);
            this.label47.TabIndex = 97;
            this.label47.Text = "Artillery";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 40);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(42, 13);
            this.label48.TabIndex = 96;
            this.label48.Text = "Infantry";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.textBox12);
            this.panel1.Controls.Add(this.textBox13);
            this.panel1.Controls.Add(this.textBox14);
            this.panel1.Controls.Add(this.textBox15);
            this.panel1.Controls.Add(this.textBox16);
            this.panel1.Controls.Add(this.textBox17);
            this.panel1.Controls.Add(this.textBox18);
            this.panel1.Controls.Add(this.textBox19);
            this.panel1.Controls.Add(this.textBox20);
            this.panel1.Controls.Add(this.textBox21);
            this.panel1.Controls.Add(this.textBox22);
            this.panel1.Controls.Add(this.textBox11);
            this.panel1.Controls.Add(this.textBox10);
            this.panel1.Controls.Add(this.textBox9);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(6, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(176, 366);
            this.panel1.TabIndex = 144;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(132, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(25, 13);
            this.label13.TabIndex = 141;
            this.label13.Text = "Hits";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(69, 9);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(31, 13);
            this.label12.TabIndex = 140;
            this.label12.Text = "Units";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(6, 9);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(52, 13);
            this.label23.TabIndex = 47;
            this.label23.Text = "Attackers";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(124, 337);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(40, 20);
            this.textBox12.TabIndex = 91;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(124, 307);
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.Size = new System.Drawing.Size(40, 20);
            this.textBox13.TabIndex = 90;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(124, 277);
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(40, 20);
            this.textBox14.TabIndex = 89;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(124, 247);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(40, 20);
            this.textBox15.TabIndex = 88;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(124, 217);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(40, 20);
            this.textBox16.TabIndex = 87;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(124, 187);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(40, 20);
            this.textBox17.TabIndex = 86;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(124, 157);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(40, 20);
            this.textBox18.TabIndex = 85;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(124, 127);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(40, 20);
            this.textBox19.TabIndex = 84;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(124, 97);
            this.textBox20.Name = "textBox20";
            this.textBox20.ReadOnly = true;
            this.textBox20.Size = new System.Drawing.Size(40, 20);
            this.textBox20.TabIndex = 83;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(124, 67);
            this.textBox21.Name = "textBox21";
            this.textBox21.ReadOnly = true;
            this.textBox21.Size = new System.Drawing.Size(40, 20);
            this.textBox21.TabIndex = 82;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(124, 37);
            this.textBox22.Name = "textBox22";
            this.textBox22.ReadOnly = true;
            this.textBox22.Size = new System.Drawing.Size(40, 20);
            this.textBox22.TabIndex = 81;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(64, 337);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(40, 20);
            this.textBox11.TabIndex = 69;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(64, 307);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(40, 20);
            this.textBox10.TabIndex = 68;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(64, 277);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(40, 20);
            this.textBox9.TabIndex = 67;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(64, 247);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(40, 20);
            this.textBox8.TabIndex = 66;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(64, 217);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(40, 20);
            this.textBox7.TabIndex = 65;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(64, 187);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(40, 20);
            this.textBox6.TabIndex = 64;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(64, 157);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(40, 20);
            this.textBox5.TabIndex = 63;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(64, 127);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(40, 20);
            this.textBox4.TabIndex = 62;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(64, 97);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(40, 20);
            this.textBox3.TabIndex = 61;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(64, 67);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(40, 20);
            this.textBox2.TabIndex = 60;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(64, 37);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(40, 20);
            this.textBox1.TabIndex = 59;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 340);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 13);
            this.label11.TabIndex = 58;
            this.label11.Text = "Battleship";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 310);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 13);
            this.label10.TabIndex = 57;
            this.label10.Text = "Carrier";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 280);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 56;
            this.label9.Text = "Cruiser";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 250);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 13);
            this.label8.TabIndex = 55;
            this.label8.Text = "Destroyer";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 220);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(26, 13);
            this.label7.TabIndex = 54;
            this.label7.Text = "Sub";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 190);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(43, 13);
            this.label6.TabIndex = 53;
            this.label6.Text = "Bomber";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 160);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(39, 13);
            this.label5.TabIndex = 52;
            this.label5.Text = "Fighter";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(21, 13);
            this.label4.TabIndex = 51;
            this.label4.Text = "AA";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 13);
            this.label3.TabIndex = 50;
            this.label3.Text = "Tanks";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 49;
            this.label2.Text = "Artillery";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 13);
            this.label1.TabIndex = 48;
            this.label1.Text = "Infantry";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(776, 449);
            this.tabControl1.TabIndex = 46;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.LightGray;
            this.tabPage3.Controls.Add(this.USIPC);
            this.tabPage3.Controls.Add(this.JapanIPC);
            this.tabPage3.Controls.Add(this.UKIPC);
            this.tabPage3.Controls.Add(this.GermanyIPC);
            this.tabPage3.Controls.Add(this.RussiaIPC);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.Notes);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.ChangeLogger);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(768, 423);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Points Manager";
            // 
            // USIPC
            // 
            this.USIPC.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::_1942GameApp.Properties.Settings.Default, "US", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.USIPC.Location = new System.Drawing.Point(254, 7);
            this.USIPC.Name = "USIPC";
            this.USIPC.Size = new System.Drawing.Size(39, 20);
            this.USIPC.TabIndex = 10;
            this.USIPC.Text = global::_1942GameApp.Properties.Settings.Default.US;
            this.USIPC.Leave += new System.EventHandler(this.textBox49_Leave);
            // 
            // JapanIPC
            // 
            this.JapanIPC.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::_1942GameApp.Properties.Settings.Default, "Japan", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.JapanIPC.Location = new System.Drawing.Point(203, 7);
            this.JapanIPC.Name = "JapanIPC";
            this.JapanIPC.Size = new System.Drawing.Size(39, 20);
            this.JapanIPC.TabIndex = 9;
            this.JapanIPC.Text = global::_1942GameApp.Properties.Settings.Default.Japan;
            this.JapanIPC.Leave += new System.EventHandler(this.textBox48_Leave);
            // 
            // UKIPC
            // 
            this.UKIPC.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::_1942GameApp.Properties.Settings.Default, "UK", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.UKIPC.Location = new System.Drawing.Point(152, 7);
            this.UKIPC.Name = "UKIPC";
            this.UKIPC.Size = new System.Drawing.Size(39, 20);
            this.UKIPC.TabIndex = 8;
            this.UKIPC.Text = global::_1942GameApp.Properties.Settings.Default.UK;
            this.UKIPC.Leave += new System.EventHandler(this.textBox47_Leave);
            // 
            // GermanyIPC
            // 
            this.GermanyIPC.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::_1942GameApp.Properties.Settings.Default, "Germany", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.GermanyIPC.Location = new System.Drawing.Point(101, 7);
            this.GermanyIPC.Name = "GermanyIPC";
            this.GermanyIPC.Size = new System.Drawing.Size(39, 20);
            this.GermanyIPC.TabIndex = 7;
            this.GermanyIPC.Text = global::_1942GameApp.Properties.Settings.Default.Germany;
            this.GermanyIPC.Leave += new System.EventHandler(this.textBox46_Leave);
            // 
            // RussiaIPC
            // 
            this.RussiaIPC.DataBindings.Add(new System.Windows.Forms.Binding("Text", global::_1942GameApp.Properties.Settings.Default, "Russia", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.RussiaIPC.Location = new System.Drawing.Point(50, 7);
            this.RussiaIPC.Name = "RussiaIPC";
            this.RussiaIPC.Size = new System.Drawing.Size(39, 20);
            this.RussiaIPC.TabIndex = 6;
            this.RussiaIPC.Text = global::_1942GameApp.Properties.Settings.Default.Russia;
            this.RussiaIPC.Leave += new System.EventHandler(this.textBox45_Leave);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(610, 6);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 13);
            this.label21.TabIndex = 5;
            this.label21.Text = "IPC Changes";
            // 
            // Notes
            // 
            this.Notes.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Notes.Location = new System.Drawing.Point(497, 26);
            this.Notes.Name = "Notes";
            this.Notes.Size = new System.Drawing.Size(265, 368);
            this.Notes.TabIndex = 4;
            this.Notes.Text = "";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(374, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(65, 13);
            this.label20.TabIndex = 3;
            this.label20.Text = "Change Log";
            // 
            // ChangeLogger
            // 
            this.ChangeLogger.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.ChangeLogger.Location = new System.Drawing.Point(324, 26);
            this.ChangeLogger.Name = "ChangeLogger";
            this.ChangeLogger.Size = new System.Drawing.Size(167, 368);
            this.ChangeLogger.TabIndex = 2;
            this.ChangeLogger.Text = "";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.LightGray;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Russia,
            this.Germany,
            this.UK,
            this.Japan,
            this.US});
            this.dataGridView1.Location = new System.Drawing.Point(6, 26);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Size = new System.Drawing.Size(311, 368);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            this.dataGridView1.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_ColumnHeaderMouseClick);
            // 
            // Russia
            // 
            this.Russia.HeaderText = "Russia";
            this.Russia.Name = "Russia";
            this.Russia.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Russia.Width = 50;
            // 
            // Germany
            // 
            this.Germany.HeaderText = "Germany";
            this.Germany.Name = "Germany";
            this.Germany.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Germany.Width = 50;
            // 
            // UK
            // 
            this.UK.HeaderText = "UK";
            this.UK.Name = "UK";
            this.UK.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.UK.Width = 50;
            // 
            // Japan
            // 
            this.Japan.HeaderText = "Japan";
            this.Japan.Name = "Japan";
            this.Japan.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Japan.Width = 50;
            // 
            // US
            // 
            this.US.HeaderText = "US";
            this.US.Name = "US";
            this.US.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.US.Width = 50;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.panel7);
            this.tabPage2.Controls.Add(this.panel5);
            this.tabPage2.Controls.Add(this.panel4);
            this.tabPage2.Controls.Add(this.panel3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(768, 423);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Special Phase";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Teal;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.CustomReset);
            this.panel7.Controls.Add(this.button2);
            this.panel7.Controls.Add(this.label63);
            this.panel7.Controls.Add(this.CustomBox);
            this.panel7.Controls.Add(this.CustomHits);
            this.panel7.Controls.Add(this.CustomStrength);
            this.panel7.Controls.Add(this.CustomUnitCount);
            this.panel7.Controls.Add(this.label64);
            this.panel7.Controls.Add(this.label65);
            this.panel7.Controls.Add(this.label66);
            this.panel7.Location = new System.Drawing.Point(566, 6);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(180, 411);
            this.panel7.TabIndex = 6;
            // 
            // CustomReset
            // 
            this.CustomReset.Location = new System.Drawing.Point(96, 373);
            this.CustomReset.Name = "CustomReset";
            this.CustomReset.Size = new System.Drawing.Size(75, 23);
            this.CustomReset.TabIndex = 12;
            this.CustomReset.Text = "Reset";
            this.CustomReset.UseVisualStyleBackColor = true;
            this.CustomReset.Click += new System.EventHandler(this.CustomReset_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(3, 373);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Go";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(60, 10);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(72, 13);
            this.label63.TabIndex = 7;
            this.label63.Text = "Custom Battle";
            // 
            // CustomBox
            // 
            this.CustomBox.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.CustomBox.Location = new System.Drawing.Point(3, 147);
            this.CustomBox.Name = "CustomBox";
            this.CustomBox.Size = new System.Drawing.Size(168, 220);
            this.CustomBox.TabIndex = 6;
            this.CustomBox.Text = "";
            // 
            // CustomHits
            // 
            this.CustomHits.Location = new System.Drawing.Point(80, 105);
            this.CustomHits.Name = "CustomHits";
            this.CustomHits.Size = new System.Drawing.Size(58, 20);
            this.CustomHits.TabIndex = 5;
            this.CustomHits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // CustomStrength
            // 
            this.CustomStrength.BackColor = System.Drawing.Color.White;
            this.CustomStrength.Location = new System.Drawing.Point(80, 70);
            this.CustomStrength.Name = "CustomStrength";
            this.CustomStrength.Size = new System.Drawing.Size(58, 20);
            this.CustomStrength.TabIndex = 4;
            this.CustomStrength.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // CustomUnitCount
            // 
            this.CustomUnitCount.BackColor = System.Drawing.Color.White;
            this.CustomUnitCount.Location = new System.Drawing.Point(80, 35);
            this.CustomUnitCount.Name = "CustomUnitCount";
            this.CustomUnitCount.Size = new System.Drawing.Size(58, 20);
            this.CustomUnitCount.TabIndex = 3;
            this.CustomUnitCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(49, 108);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(25, 13);
            this.label64.TabIndex = 2;
            this.label64.Text = "Hits";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(27, 73);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(47, 13);
            this.label65.TabIndex = 1;
            this.label65.Text = "Strength";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(17, 38);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(57, 13);
            this.label66.TabIndex = 0;
            this.label66.Text = "Unit Count";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.BombingReset);
            this.panel5.Controls.Add(this.BombingButton);
            this.panel5.Controls.Add(this.label34);
            this.panel5.Controls.Add(this.BombingBox);
            this.panel5.Controls.Add(this.InterceptorCount);
            this.panel5.Controls.Add(this.EscortCount);
            this.panel5.Controls.Add(this.BomberCount);
            this.panel5.Controls.Add(this.label35);
            this.panel5.Controls.Add(this.label36);
            this.panel5.Controls.Add(this.label37);
            this.panel5.Location = new System.Drawing.Point(384, 6);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(180, 411);
            this.panel5.TabIndex = 5;
            // 
            // BombingReset
            // 
            this.BombingReset.Location = new System.Drawing.Point(95, 373);
            this.BombingReset.Name = "BombingReset";
            this.BombingReset.Size = new System.Drawing.Size(75, 23);
            this.BombingReset.TabIndex = 11;
            this.BombingReset.Text = "Reset";
            this.BombingReset.UseVisualStyleBackColor = true;
            this.BombingReset.Click += new System.EventHandler(this.BombingReset_Click);
            // 
            // BombingButton
            // 
            this.BombingButton.Location = new System.Drawing.Point(3, 373);
            this.BombingButton.Name = "BombingButton";
            this.BombingButton.Size = new System.Drawing.Size(75, 23);
            this.BombingButton.TabIndex = 9;
            this.BombingButton.Text = "Go";
            this.BombingButton.UseVisualStyleBackColor = true;
            this.BombingButton.Click += new System.EventHandler(this.BombingButton_Click);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(60, 10);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(73, 13);
            this.label34.TabIndex = 7;
            this.label34.Text = "Bombing Raid";
            // 
            // BombingBox
            // 
            this.BombingBox.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.BombingBox.Location = new System.Drawing.Point(3, 147);
            this.BombingBox.Name = "BombingBox";
            this.BombingBox.Size = new System.Drawing.Size(168, 220);
            this.BombingBox.TabIndex = 6;
            this.BombingBox.Text = "";
            // 
            // InterceptorCount
            // 
            this.InterceptorCount.Location = new System.Drawing.Point(80, 105);
            this.InterceptorCount.Name = "InterceptorCount";
            this.InterceptorCount.Size = new System.Drawing.Size(58, 20);
            this.InterceptorCount.TabIndex = 5;
            this.InterceptorCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // EscortCount
            // 
            this.EscortCount.BackColor = System.Drawing.Color.White;
            this.EscortCount.Location = new System.Drawing.Point(80, 70);
            this.EscortCount.Name = "EscortCount";
            this.EscortCount.Size = new System.Drawing.Size(58, 20);
            this.EscortCount.TabIndex = 4;
            this.EscortCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BomberCount
            // 
            this.BomberCount.BackColor = System.Drawing.Color.White;
            this.BomberCount.Location = new System.Drawing.Point(80, 35);
            this.BomberCount.Name = "BomberCount";
            this.BomberCount.Size = new System.Drawing.Size(58, 20);
            this.BomberCount.TabIndex = 3;
            this.BomberCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(11, 108);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(63, 13);
            this.label35.TabIndex = 2;
            this.label35.Text = "Interceptors";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(32, 73);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(42, 13);
            this.label36.TabIndex = 1;
            this.label36.Text = "Escorts";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(26, 38);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(48, 13);
            this.label37.TabIndex = 0;
            this.label37.Text = "Bombers";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SeaGreen;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.OffShoreReset);
            this.panel4.Controls.Add(this.OffShoreButton);
            this.panel4.Controls.Add(this.label30);
            this.panel4.Controls.Add(this.OffShoreBox);
            this.panel4.Controls.Add(this.OffShoreHits);
            this.panel4.Controls.Add(this.BattleshipCount);
            this.panel4.Controls.Add(this.CruisersCount);
            this.panel4.Controls.Add(this.label31);
            this.panel4.Controls.Add(this.label32);
            this.panel4.Controls.Add(this.label33);
            this.panel4.Location = new System.Drawing.Point(202, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(180, 411);
            this.panel4.TabIndex = 4;
            // 
            // OffShoreReset
            // 
            this.OffShoreReset.Location = new System.Drawing.Point(96, 373);
            this.OffShoreReset.Name = "OffShoreReset";
            this.OffShoreReset.Size = new System.Drawing.Size(75, 23);
            this.OffShoreReset.TabIndex = 10;
            this.OffShoreReset.Text = "Reset";
            this.OffShoreReset.UseVisualStyleBackColor = true;
            this.OffShoreReset.Click += new System.EventHandler(this.OffShoreReset_Click);
            // 
            // OffShoreButton
            // 
            this.OffShoreButton.Location = new System.Drawing.Point(3, 373);
            this.OffShoreButton.Name = "OffShoreButton";
            this.OffShoreButton.Size = new System.Drawing.Size(75, 23);
            this.OffShoreButton.TabIndex = 9;
            this.OffShoreButton.Text = "Go";
            this.OffShoreButton.UseVisualStyleBackColor = true;
            this.OffShoreButton.Click += new System.EventHandler(this.OffShoreButton_Click);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(25, 10);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(120, 13);
            this.label30.TabIndex = 7;
            this.label30.Text = "Off-Shore Bombardment";
            // 
            // OffShoreBox
            // 
            this.OffShoreBox.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.OffShoreBox.Location = new System.Drawing.Point(3, 147);
            this.OffShoreBox.Name = "OffShoreBox";
            this.OffShoreBox.Size = new System.Drawing.Size(168, 220);
            this.OffShoreBox.TabIndex = 6;
            this.OffShoreBox.Text = "";
            // 
            // OffShoreHits
            // 
            this.OffShoreHits.Location = new System.Drawing.Point(89, 113);
            this.OffShoreHits.Name = "OffShoreHits";
            this.OffShoreHits.ReadOnly = true;
            this.OffShoreHits.Size = new System.Drawing.Size(47, 20);
            this.OffShoreHits.TabIndex = 5;
            this.OffShoreHits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // BattleshipCount
            // 
            this.BattleshipCount.Location = new System.Drawing.Point(89, 73);
            this.BattleshipCount.Name = "BattleshipCount";
            this.BattleshipCount.Size = new System.Drawing.Size(47, 20);
            this.BattleshipCount.TabIndex = 4;
            this.BattleshipCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // CruisersCount
            // 
            this.CruisersCount.Location = new System.Drawing.Point(89, 33);
            this.CruisersCount.Name = "CruisersCount";
            this.CruisersCount.Size = new System.Drawing.Size(47, 20);
            this.CruisersCount.TabIndex = 3;
            this.CruisersCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(58, 116);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(25, 13);
            this.label31.TabIndex = 2;
            this.label31.Text = "Hits";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(25, 76);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(58, 13);
            this.label32.TabIndex = 1;
            this.label32.Text = "Battleships";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(39, 36);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 13);
            this.label33.TabIndex = 0;
            this.label33.Text = "Cruisers";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.LightGreen;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.AAReset);
            this.panel3.Controls.Add(this.AAButton);
            this.panel3.Controls.Add(this.label29);
            this.panel3.Controls.Add(this.AATextBox);
            this.panel3.Controls.Add(this.AAHits);
            this.panel3.Controls.Add(this.HostilePlanes);
            this.panel3.Controls.Add(this.AACount);
            this.panel3.Controls.Add(this.label28);
            this.panel3.Controls.Add(this.label27);
            this.panel3.Controls.Add(this.label26);
            this.panel3.Location = new System.Drawing.Point(20, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(180, 411);
            this.panel3.TabIndex = 3;
            // 
            // AAReset
            // 
            this.AAReset.Location = new System.Drawing.Point(96, 373);
            this.AAReset.Name = "AAReset";
            this.AAReset.Size = new System.Drawing.Size(75, 23);
            this.AAReset.TabIndex = 9;
            this.AAReset.Text = "Reset";
            this.AAReset.UseVisualStyleBackColor = true;
            this.AAReset.Click += new System.EventHandler(this.AAReset_Click);
            // 
            // AAButton
            // 
            this.AAButton.Location = new System.Drawing.Point(3, 373);
            this.AAButton.Name = "AAButton";
            this.AAButton.Size = new System.Drawing.Size(75, 23);
            this.AAButton.TabIndex = 8;
            this.AAButton.Text = "Go";
            this.AAButton.UseVisualStyleBackColor = true;
            this.AAButton.Click += new System.EventHandler(this.AAButton_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(50, 10);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(97, 13);
            this.label29.TabIndex = 7;
            this.label29.Text = "AA Defense Phase";
            // 
            // AATextBox
            // 
            this.AATextBox.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.AATextBox.Location = new System.Drawing.Point(3, 147);
            this.AATextBox.Name = "AATextBox";
            this.AATextBox.Size = new System.Drawing.Size(168, 220);
            this.AATextBox.TabIndex = 6;
            this.AATextBox.Text = "";
            // 
            // AAHits
            // 
            this.AAHits.Location = new System.Drawing.Point(89, 113);
            this.AAHits.Name = "AAHits";
            this.AAHits.ReadOnly = true;
            this.AAHits.Size = new System.Drawing.Size(47, 20);
            this.AAHits.TabIndex = 5;
            this.AAHits.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // HostilePlanes
            // 
            this.HostilePlanes.Location = new System.Drawing.Point(89, 73);
            this.HostilePlanes.Name = "HostilePlanes";
            this.HostilePlanes.Size = new System.Drawing.Size(47, 20);
            this.HostilePlanes.TabIndex = 4;
            this.HostilePlanes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // AACount
            // 
            this.AACount.Location = new System.Drawing.Point(89, 33);
            this.AACount.Name = "AACount";
            this.AACount.Size = new System.Drawing.Size(47, 20);
            this.AACount.TabIndex = 3;
            this.AACount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(58, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(25, 13);
            this.label28.TabIndex = 2;
            this.label28.Text = "Hits";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(9, 76);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(74, 13);
            this.label27.TabIndex = 1;
            this.label27.Text = "Hostile Planes";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(31, 36);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(52, 13);
            this.label26.TabIndex = 0;
            this.label26.Text = "AA Count";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.Silver;
            this.tabPage5.Controls.Add(this.label49);
            this.tabPage5.Controls.Add(this.GameLog);
            this.tabPage5.Controls.Add(this.label24);
            this.tabPage5.Controls.Add(this.label22);
            this.tabPage5.Controls.Add(this.DefenderLog);
            this.tabPage5.Controls.Add(this.AttackerLog);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(768, 423);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Game Log";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.Location = new System.Drawing.Point(549, 6);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(58, 15);
            this.label49.TabIndex = 5;
            this.label49.Text = "Game Log";
            // 
            // GameLog
            // 
            this.GameLog.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.GameLog.Location = new System.Drawing.Point(389, 24);
            this.GameLog.Name = "GameLog";
            this.GameLog.Size = new System.Drawing.Size(373, 302);
            this.GameLog.TabIndex = 4;
            this.GameLog.Text = "";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Location = new System.Drawing.Point(244, 6);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(74, 15);
            this.label24.TabIndex = 3;
            this.label24.Text = "Defender Log";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Location = new System.Drawing.Point(64, 6);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 15);
            this.label22.TabIndex = 2;
            this.label22.Text = "Attacker Log";
            // 
            // DefenderLog
            // 
            this.DefenderLog.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.DefenderLog.Location = new System.Drawing.Point(199, 24);
            this.DefenderLog.Name = "DefenderLog";
            this.DefenderLog.Size = new System.Drawing.Size(161, 393);
            this.DefenderLog.TabIndex = 1;
            this.DefenderLog.Text = "";
            // 
            // AttackerLog
            // 
            this.AttackerLog.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.AttackerLog.Location = new System.Drawing.Point(17, 24);
            this.AttackerLog.Name = "AttackerLog";
            this.AttackerLog.Size = new System.Drawing.Size(161, 393);
            this.AttackerLog.TabIndex = 0;
            this.AttackerLog.Text = "";
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.Silver;
            this.tabPage4.Controls.Add(this.label62);
            this.tabPage4.Controls.Add(this.label61);
            this.tabPage4.Controls.Add(this.defenseBox11);
            this.tabPage4.Controls.Add(this.defenseBox10);
            this.tabPage4.Controls.Add(this.defenseBox9);
            this.tabPage4.Controls.Add(this.defenseBox8);
            this.tabPage4.Controls.Add(this.defenseBox7);
            this.tabPage4.Controls.Add(this.defenseBox6);
            this.tabPage4.Controls.Add(this.defenseBox5);
            this.tabPage4.Controls.Add(this.defenseBox4);
            this.tabPage4.Controls.Add(this.defenseBox3);
            this.tabPage4.Controls.Add(this.defenseBox2);
            this.tabPage4.Controls.Add(this.defenseBox1);
            this.tabPage4.Controls.Add(this.attackBox11);
            this.tabPage4.Controls.Add(this.attackBox10);
            this.tabPage4.Controls.Add(this.attackBox9);
            this.tabPage4.Controls.Add(this.attackBox8);
            this.tabPage4.Controls.Add(this.attackBox7);
            this.tabPage4.Controls.Add(this.attackBox6);
            this.tabPage4.Controls.Add(this.attackBox5);
            this.tabPage4.Controls.Add(this.attackBox4);
            this.tabPage4.Controls.Add(this.attackBox3);
            this.tabPage4.Controls.Add(this.attackBox2);
            this.tabPage4.Controls.Add(this.attackBox1);
            this.tabPage4.Controls.Add(this.label50);
            this.tabPage4.Controls.Add(this.label51);
            this.tabPage4.Controls.Add(this.label52);
            this.tabPage4.Controls.Add(this.label53);
            this.tabPage4.Controls.Add(this.label54);
            this.tabPage4.Controls.Add(this.label55);
            this.tabPage4.Controls.Add(this.label56);
            this.tabPage4.Controls.Add(this.label57);
            this.tabPage4.Controls.Add(this.label58);
            this.tabPage4.Controls.Add(this.label59);
            this.tabPage4.Controls.Add(this.label60);
            this.tabPage4.Controls.Add(this.panel6);
            this.tabPage4.Controls.Add(this.NewFileBox);
            this.tabPage4.Controls.Add(this.FileBox);
            this.tabPage4.Controls.Add(this.CreateNewFile);
            this.tabPage4.Controls.Add(this.LoadFile);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(768, 423);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Settings";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(135, 11);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(47, 13);
            this.label62.TabIndex = 104;
            this.label62.Text = "Defense";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(76, 11);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(38, 13);
            this.label61.TabIndex = 103;
            this.label61.Text = "Attack";
            // 
            // defenseBox11
            // 
            this.defenseBox11.Location = new System.Drawing.Point(136, 327);
            this.defenseBox11.Name = "defenseBox11";
            this.defenseBox11.Size = new System.Drawing.Size(40, 20);
            this.defenseBox11.TabIndex = 102;
            // 
            // defenseBox10
            // 
            this.defenseBox10.Location = new System.Drawing.Point(136, 297);
            this.defenseBox10.Name = "defenseBox10";
            this.defenseBox10.Size = new System.Drawing.Size(40, 20);
            this.defenseBox10.TabIndex = 101;
            // 
            // defenseBox9
            // 
            this.defenseBox9.Location = new System.Drawing.Point(136, 267);
            this.defenseBox9.Name = "defenseBox9";
            this.defenseBox9.Size = new System.Drawing.Size(40, 20);
            this.defenseBox9.TabIndex = 100;
            // 
            // defenseBox8
            // 
            this.defenseBox8.Location = new System.Drawing.Point(136, 237);
            this.defenseBox8.Name = "defenseBox8";
            this.defenseBox8.Size = new System.Drawing.Size(40, 20);
            this.defenseBox8.TabIndex = 99;
            // 
            // defenseBox7
            // 
            this.defenseBox7.Location = new System.Drawing.Point(136, 207);
            this.defenseBox7.Name = "defenseBox7";
            this.defenseBox7.Size = new System.Drawing.Size(40, 20);
            this.defenseBox7.TabIndex = 98;
            // 
            // defenseBox6
            // 
            this.defenseBox6.Location = new System.Drawing.Point(136, 177);
            this.defenseBox6.Name = "defenseBox6";
            this.defenseBox6.Size = new System.Drawing.Size(40, 20);
            this.defenseBox6.TabIndex = 97;
            // 
            // defenseBox5
            // 
            this.defenseBox5.Location = new System.Drawing.Point(136, 147);
            this.defenseBox5.Name = "defenseBox5";
            this.defenseBox5.Size = new System.Drawing.Size(40, 20);
            this.defenseBox5.TabIndex = 96;
            // 
            // defenseBox4
            // 
            this.defenseBox4.Location = new System.Drawing.Point(136, 117);
            this.defenseBox4.Name = "defenseBox4";
            this.defenseBox4.Size = new System.Drawing.Size(40, 20);
            this.defenseBox4.TabIndex = 95;
            // 
            // defenseBox3
            // 
            this.defenseBox3.Location = new System.Drawing.Point(136, 87);
            this.defenseBox3.Name = "defenseBox3";
            this.defenseBox3.Size = new System.Drawing.Size(40, 20);
            this.defenseBox3.TabIndex = 94;
            // 
            // defenseBox2
            // 
            this.defenseBox2.Location = new System.Drawing.Point(136, 57);
            this.defenseBox2.Name = "defenseBox2";
            this.defenseBox2.Size = new System.Drawing.Size(40, 20);
            this.defenseBox2.TabIndex = 93;
            // 
            // defenseBox1
            // 
            this.defenseBox1.Location = new System.Drawing.Point(136, 27);
            this.defenseBox1.Name = "defenseBox1";
            this.defenseBox1.Size = new System.Drawing.Size(40, 20);
            this.defenseBox1.TabIndex = 92;
            // 
            // attackBox11
            // 
            this.attackBox11.Location = new System.Drawing.Point(77, 327);
            this.attackBox11.Name = "attackBox11";
            this.attackBox11.Size = new System.Drawing.Size(40, 20);
            this.attackBox11.TabIndex = 91;
            // 
            // attackBox10
            // 
            this.attackBox10.Location = new System.Drawing.Point(77, 297);
            this.attackBox10.Name = "attackBox10";
            this.attackBox10.Size = new System.Drawing.Size(40, 20);
            this.attackBox10.TabIndex = 90;
            // 
            // attackBox9
            // 
            this.attackBox9.Location = new System.Drawing.Point(77, 267);
            this.attackBox9.Name = "attackBox9";
            this.attackBox9.Size = new System.Drawing.Size(40, 20);
            this.attackBox9.TabIndex = 89;
            // 
            // attackBox8
            // 
            this.attackBox8.Location = new System.Drawing.Point(77, 237);
            this.attackBox8.Name = "attackBox8";
            this.attackBox8.Size = new System.Drawing.Size(40, 20);
            this.attackBox8.TabIndex = 88;
            // 
            // attackBox7
            // 
            this.attackBox7.Location = new System.Drawing.Point(77, 207);
            this.attackBox7.Name = "attackBox7";
            this.attackBox7.Size = new System.Drawing.Size(40, 20);
            this.attackBox7.TabIndex = 87;
            // 
            // attackBox6
            // 
            this.attackBox6.Location = new System.Drawing.Point(77, 177);
            this.attackBox6.Name = "attackBox6";
            this.attackBox6.Size = new System.Drawing.Size(40, 20);
            this.attackBox6.TabIndex = 86;
            // 
            // attackBox5
            // 
            this.attackBox5.Location = new System.Drawing.Point(77, 147);
            this.attackBox5.Name = "attackBox5";
            this.attackBox5.Size = new System.Drawing.Size(40, 20);
            this.attackBox5.TabIndex = 85;
            // 
            // attackBox4
            // 
            this.attackBox4.Location = new System.Drawing.Point(77, 117);
            this.attackBox4.Name = "attackBox4";
            this.attackBox4.Size = new System.Drawing.Size(40, 20);
            this.attackBox4.TabIndex = 84;
            // 
            // attackBox3
            // 
            this.attackBox3.Location = new System.Drawing.Point(77, 87);
            this.attackBox3.Name = "attackBox3";
            this.attackBox3.Size = new System.Drawing.Size(40, 20);
            this.attackBox3.TabIndex = 83;
            // 
            // attackBox2
            // 
            this.attackBox2.Location = new System.Drawing.Point(77, 57);
            this.attackBox2.Name = "attackBox2";
            this.attackBox2.Size = new System.Drawing.Size(40, 20);
            this.attackBox2.TabIndex = 82;
            // 
            // attackBox1
            // 
            this.attackBox1.Location = new System.Drawing.Point(77, 27);
            this.attackBox1.Name = "attackBox1";
            this.attackBox1.Size = new System.Drawing.Size(40, 20);
            this.attackBox1.TabIndex = 81;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(19, 330);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(53, 13);
            this.label50.TabIndex = 80;
            this.label50.Text = "Battleship";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(19, 300);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(37, 13);
            this.label51.TabIndex = 79;
            this.label51.Text = "Carrier";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(19, 270);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(39, 13);
            this.label52.TabIndex = 78;
            this.label52.Text = "Cruiser";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(19, 240);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(52, 13);
            this.label53.TabIndex = 77;
            this.label53.Text = "Destroyer";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(19, 210);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(26, 13);
            this.label54.TabIndex = 76;
            this.label54.Text = "Sub";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(19, 180);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(43, 13);
            this.label55.TabIndex = 75;
            this.label55.Text = "Bomber";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(19, 150);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(39, 13);
            this.label56.TabIndex = 74;
            this.label56.Text = "Fighter";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(19, 120);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(21, 13);
            this.label57.TabIndex = 73;
            this.label57.Text = "AA";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(19, 90);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(37, 13);
            this.label58.TabIndex = 72;
            this.label58.Text = "Tanks";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(19, 60);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(40, 13);
            this.label59.TabIndex = 71;
            this.label59.Text = "Artillery";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(19, 30);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(42, 13);
            this.label60.TabIndex = 70;
            this.label60.Text = "Infantry";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.ArtInfHelp);
            this.panel6.Controls.Add(this.ArtInfCheckBox);
            this.panel6.Location = new System.Drawing.Point(377, 3);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(388, 413);
            this.panel6.TabIndex = 15;
            // 
            // ArtInfHelp
            // 
            this.ArtInfHelp.Location = new System.Drawing.Point(182, 7);
            this.ArtInfHelp.Name = "ArtInfHelp";
            this.ArtInfHelp.Size = new System.Drawing.Size(20, 23);
            this.ArtInfHelp.TabIndex = 1;
            this.ArtInfHelp.Text = "?";
            this.ArtInfHelp.UseVisualStyleBackColor = true;
            this.ArtInfHelp.Click += new System.EventHandler(this.ArtInfHelp_Click);
            // 
            // ArtInfCheckBox
            // 
            this.ArtInfCheckBox.AutoSize = true;
            this.ArtInfCheckBox.Location = new System.Drawing.Point(42, 11);
            this.ArtInfCheckBox.Name = "ArtInfCheckBox";
            this.ArtInfCheckBox.Size = new System.Drawing.Size(134, 17);
            this.ArtInfCheckBox.TabIndex = 0;
            this.ArtInfCheckBox.Text = "Artillery/Infantry Pairing";
            this.ArtInfCheckBox.UseVisualStyleBackColor = true;
            this.ArtInfCheckBox.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // NewFileBox
            // 
            this.NewFileBox.Location = new System.Drawing.Point(87, 395);
            this.NewFileBox.Name = "NewFileBox";
            this.NewFileBox.Size = new System.Drawing.Size(284, 20);
            this.NewFileBox.TabIndex = 14;
            // 
            // FileBox
            // 
            this.FileBox.Location = new System.Drawing.Point(87, 354);
            this.FileBox.Name = "FileBox";
            this.FileBox.Size = new System.Drawing.Size(284, 20);
            this.FileBox.TabIndex = 13;
            // 
            // CreateNewFile
            // 
            this.CreateNewFile.Location = new System.Drawing.Point(6, 393);
            this.CreateNewFile.Name = "CreateNewFile";
            this.CreateNewFile.Size = new System.Drawing.Size(75, 23);
            this.CreateNewFile.TabIndex = 12;
            this.CreateNewFile.Text = "Create New";
            this.CreateNewFile.UseVisualStyleBackColor = true;
            this.CreateNewFile.Click += new System.EventHandler(this.CreateNewFile_Click_1);
            // 
            // LoadFile
            // 
            this.LoadFile.Location = new System.Drawing.Point(6, 352);
            this.LoadFile.Name = "LoadFile";
            this.LoadFile.Size = new System.Drawing.Size(75, 23);
            this.LoadFile.TabIndex = 11;
            this.LoadFile.Text = "Load File";
            this.LoadFile.UseVisualStyleBackColor = true;
            this.LoadFile.Click += new System.EventHandler(this.LoadFile_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 473);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "1942";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox DefenderMisses;
        private System.Windows.Forms.TextBox DefenderHits;
        private System.Windows.Forms.TextBox AttackerMisses;
        private System.Windows.Forms.TextBox AttackerHits;
        private System.Windows.Forms.RichTextBox AttackerTextBox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.RichTextBox DefenderSpecialConditions;
        private System.Windows.Forms.RichTextBox AttackerSpecialConditions;
        private System.Windows.Forms.RichTextBox DefenderTextBox;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.RichTextBox ChangeLogger;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.RichTextBox Notes;
        private System.Windows.Forms.Button FightButton;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.RichTextBox DefenderLog;
        private System.Windows.Forms.RichTextBox AttackerLog;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.RichTextBox BombingBox;
        private System.Windows.Forms.TextBox InterceptorCount;
        private System.Windows.Forms.TextBox EscortCount;
        private System.Windows.Forms.TextBox BomberCount;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RichTextBox OffShoreBox;
        private System.Windows.Forms.TextBox OffShoreHits;
        private System.Windows.Forms.TextBox BattleshipCount;
        private System.Windows.Forms.TextBox CruisersCount;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RichTextBox AATextBox;
        private System.Windows.Forms.TextBox AAHits;
        private System.Windows.Forms.TextBox HostilePlanes;
        private System.Windows.Forms.TextBox AACount;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Button BombingButton;
        private System.Windows.Forms.Button OffShoreButton;
        private System.Windows.Forms.Button AAButton;
        private System.Windows.Forms.CheckBox ArtInfCheckBox;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.RichTextBox GameLog;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox defenseBox11;
        private System.Windows.Forms.TextBox defenseBox10;
        private System.Windows.Forms.TextBox defenseBox9;
        private System.Windows.Forms.TextBox defenseBox8;
        private System.Windows.Forms.TextBox defenseBox7;
        private System.Windows.Forms.TextBox defenseBox6;
        private System.Windows.Forms.TextBox defenseBox5;
        private System.Windows.Forms.TextBox defenseBox4;
        private System.Windows.Forms.TextBox defenseBox3;
        private System.Windows.Forms.TextBox defenseBox2;
        private System.Windows.Forms.TextBox defenseBox1;
        private System.Windows.Forms.TextBox attackBox11;
        private System.Windows.Forms.TextBox attackBox10;
        private System.Windows.Forms.TextBox attackBox9;
        private System.Windows.Forms.TextBox attackBox8;
        private System.Windows.Forms.TextBox attackBox7;
        private System.Windows.Forms.TextBox attackBox6;
        private System.Windows.Forms.TextBox attackBox5;
        private System.Windows.Forms.TextBox attackBox4;
        private System.Windows.Forms.TextBox attackBox3;
        private System.Windows.Forms.TextBox attackBox2;
        private System.Windows.Forms.TextBox attackBox1;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox NewFileBox;
        private System.Windows.Forms.TextBox FileBox;
        private System.Windows.Forms.Button CreateNewFile;
        private System.Windows.Forms.Button LoadFile;
        private System.Windows.Forms.TextBox USIPC;
        private System.Windows.Forms.TextBox JapanIPC;
        private System.Windows.Forms.TextBox UKIPC;
        private System.Windows.Forms.TextBox GermanyIPC;
        private System.Windows.Forms.TextBox RussiaIPC;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.RichTextBox CustomBox;
        private System.Windows.Forms.TextBox CustomHits;
        private System.Windows.Forms.TextBox CustomStrength;
        private System.Windows.Forms.TextBox CustomUnitCount;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Button CustomReset;
        private System.Windows.Forms.Button BombingReset;
        private System.Windows.Forms.Button OffShoreReset;
        private System.Windows.Forms.Button AAReset;
        private System.Windows.Forms.DataGridViewTextBoxColumn Russia;
        private System.Windows.Forms.DataGridViewTextBoxColumn Germany;
        private System.Windows.Forms.DataGridViewTextBoxColumn UK;
        private System.Windows.Forms.DataGridViewTextBoxColumn Japan;
        private System.Windows.Forms.DataGridViewTextBoxColumn US;
        private System.Windows.Forms.Button ArtInfHelp;
    }
}

