﻿namespace T3Production
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.RunHelp = new System.Windows.Forms.Button();
            this.ReactionRunsTable = new System.Windows.Forms.DataGridView();
            this.Run = new System.Windows.Forms.Button();
            this.ReactionsTable = new System.Windows.Forms.DataGridView();
            this.MineralsTable = new System.Windows.Forms.DataGridView();
            this.SalvageTable = new System.Windows.Forms.DataGridView();
            this.ItemsNeededBox = new System.Windows.Forms.RichTextBox();
            this.GasTable = new System.Windows.Forms.DataGridView();
            this.dataGridViewT3Input = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.CompHelp = new System.Windows.Forms.Button();
            this.ComponentsOwnedTable = new System.Windows.Forms.DataGridView();
            this.LoadDefaults = new System.Windows.Forms.Button();
            this.Help = new System.Windows.Forms.Button();
            this.ApplyBonuses = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Box7 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.Box6 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Box5 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Box4 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Box3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Box2 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.Box1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.ReactionRigBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.StructureReactionBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.BluepringMEBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.RigBonusBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.StructureBonusBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.SalvageLoad = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ReactionLoad = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.ReactionReqLoad = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.HullSubLoad = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ReactionRunsTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReactionsTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MineralsTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalvageTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GasTable)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewT3Input)).BeginInit();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ComponentsOwnedTable)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(13, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1325, 686);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.MediumTurquoise;
            this.tabPage5.Controls.Add(this.RunHelp);
            this.tabPage5.Controls.Add(this.ReactionRunsTable);
            this.tabPage5.Controls.Add(this.Run);
            this.tabPage5.Controls.Add(this.ReactionsTable);
            this.tabPage5.Controls.Add(this.MineralsTable);
            this.tabPage5.Controls.Add(this.SalvageTable);
            this.tabPage5.Controls.Add(this.ItemsNeededBox);
            this.tabPage5.Controls.Add(this.GasTable);
            this.tabPage5.Controls.Add(this.dataGridViewT3Input);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(1317, 660);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Production Input";
            // 
            // RunHelp
            // 
            this.RunHelp.Location = new System.Drawing.Point(131, 17);
            this.RunHelp.Name = "RunHelp";
            this.RunHelp.Size = new System.Drawing.Size(27, 23);
            this.RunHelp.TabIndex = 9;
            this.RunHelp.Text = "?";
            this.RunHelp.UseVisualStyleBackColor = true;
            this.RunHelp.Click += new System.EventHandler(this.RunHelp_Click);
            // 
            // ReactionRunsTable
            // 
            this.ReactionRunsTable.BackgroundColor = System.Drawing.Color.MediumTurquoise;
            this.ReactionRunsTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ReactionRunsTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.ReactionRunsTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ReactionRunsTable.DefaultCellStyle = dataGridViewCellStyle2;
            this.ReactionRunsTable.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.ReactionRunsTable.Location = new System.Drawing.Point(920, 331);
            this.ReactionRunsTable.Name = "ReactionRunsTable";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ReactionRunsTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.ReactionRunsTable.RowHeadersWidth = 175;
            this.ReactionRunsTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.ReactionRunsTable.Size = new System.Drawing.Size(318, 323);
            this.ReactionRunsTable.TabIndex = 8;
            this.ReactionRunsTable.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.ReactionRunsTable_CellEndEdit);
            // 
            // Run
            // 
            this.Run.Location = new System.Drawing.Point(50, 17);
            this.Run.Name = "Run";
            this.Run.Size = new System.Drawing.Size(75, 23);
            this.Run.TabIndex = 7;
            this.Run.Text = "Run";
            this.Run.UseVisualStyleBackColor = true;
            this.Run.Click += new System.EventHandler(this.button1_Click);
            // 
            // ReactionsTable
            // 
            this.ReactionsTable.BackgroundColor = System.Drawing.Color.MediumTurquoise;
            this.ReactionsTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ReactionsTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.ReactionsTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ReactionsTable.DefaultCellStyle = dataGridViewCellStyle5;
            this.ReactionsTable.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.ReactionsTable.Location = new System.Drawing.Point(920, 17);
            this.ReactionsTable.Name = "ReactionsTable";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ReactionsTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.ReactionsTable.RowHeadersWidth = 175;
            this.ReactionsTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.ReactionsTable.Size = new System.Drawing.Size(388, 307);
            this.ReactionsTable.TabIndex = 6;
            // 
            // MineralsTable
            // 
            this.MineralsTable.BackgroundColor = System.Drawing.Color.MediumTurquoise;
            this.MineralsTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MineralsTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.MineralsTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.MineralsTable.DefaultCellStyle = dataGridViewCellStyle8;
            this.MineralsTable.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.MineralsTable.Location = new System.Drawing.Point(264, 346);
            this.MineralsTable.Name = "MineralsTable";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.MineralsTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.MineralsTable.RowHeadersWidth = 100;
            this.MineralsTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.MineralsTable.Size = new System.Drawing.Size(259, 289);
            this.MineralsTable.TabIndex = 4;
            this.MineralsTable.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMinerals_CellEndEdit);
            // 
            // SalvageTable
            // 
            this.SalvageTable.BackgroundColor = System.Drawing.Color.MediumTurquoise;
            this.SalvageTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalvageTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.SalvageTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.SalvageTable.DefaultCellStyle = dataGridViewCellStyle11;
            this.SalvageTable.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.SalvageTable.Location = new System.Drawing.Point(529, 17);
            this.SalvageTable.Name = "SalvageTable";
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.SalvageTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.SalvageTable.RowHeadersWidth = 200;
            this.SalvageTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.SalvageTable.Size = new System.Drawing.Size(388, 614);
            this.SalvageTable.TabIndex = 3;
            this.SalvageTable.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMatsNeeded2_CellEndEdit);
            // 
            // ItemsNeededBox
            // 
            this.ItemsNeededBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ItemsNeededBox.Location = new System.Drawing.Point(18, 267);
            this.ItemsNeededBox.Name = "ItemsNeededBox";
            this.ItemsNeededBox.Size = new System.Drawing.Size(191, 375);
            this.ItemsNeededBox.TabIndex = 2;
            this.ItemsNeededBox.Text = "";
            this.ItemsNeededBox.WordWrap = false;
            // 
            // GasTable
            // 
            this.GasTable.BackgroundColor = System.Drawing.Color.MediumTurquoise;
            this.GasTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GasTable.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.GasTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.GasTable.DefaultCellStyle = dataGridViewCellStyle14;
            this.GasTable.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.GasTable.Location = new System.Drawing.Point(264, 17);
            this.GasTable.Name = "GasTable";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.GasTable.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.GasTable.RowHeadersWidth = 100;
            this.GasTable.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.GasTable.Size = new System.Drawing.Size(259, 307);
            this.GasTable.TabIndex = 1;
            this.GasTable.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewMatsNeeded_CellEndEdit);
            // 
            // dataGridViewT3Input
            // 
            this.dataGridViewT3Input.BackgroundColor = System.Drawing.Color.MediumTurquoise;
            this.dataGridViewT3Input.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.GradientActiveCaption;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewT3Input.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewT3Input.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridViewT3Input.GridColor = System.Drawing.SystemColors.ButtonShadow;
            this.dataGridViewT3Input.Location = new System.Drawing.Point(18, 46);
            this.dataGridViewT3Input.Name = "dataGridViewT3Input";
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewT3Input.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridViewT3Input.RowHeadersWidth = 100;
            this.dataGridViewT3Input.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dataGridViewT3Input.Size = new System.Drawing.Size(191, 215);
            this.dataGridViewT3Input.TabIndex = 5;
            this.dataGridViewT3Input.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewT3Input_CellEndEdit_1);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Gainsboro;
            this.tabPage6.Controls.Add(this.CompHelp);
            this.tabPage6.Controls.Add(this.ComponentsOwnedTable);
            this.tabPage6.Controls.Add(this.LoadDefaults);
            this.tabPage6.Controls.Add(this.Help);
            this.tabPage6.Controls.Add(this.ApplyBonuses);
            this.tabPage6.Controls.Add(this.panel3);
            this.tabPage6.Controls.Add(this.panel2);
            this.tabPage6.Controls.Add(this.panel1);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(1317, 660);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Production Details";
            // 
            // CompHelp
            // 
            this.CompHelp.Location = new System.Drawing.Point(542, 6);
            this.CompHelp.Name = "CompHelp";
            this.CompHelp.Size = new System.Drawing.Size(20, 23);
            this.CompHelp.TabIndex = 17;
            this.CompHelp.Text = "?";
            this.CompHelp.UseVisualStyleBackColor = true;
            this.CompHelp.Click += new System.EventHandler(this.CompHelp_Click);
            // 
            // ComponentsOwnedTable
            // 
            this.ComponentsOwnedTable.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.ComponentsOwnedTable.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.ComponentsOwnedTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ComponentsOwnedTable.Location = new System.Drawing.Point(447, 47);
            this.ComponentsOwnedTable.Name = "ComponentsOwnedTable";
            this.ComponentsOwnedTable.RowHeadersWidth = 150;
            this.ComponentsOwnedTable.Size = new System.Drawing.Size(336, 518);
            this.ComponentsOwnedTable.TabIndex = 16;
            this.ComponentsOwnedTable.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.ComponentsOwnedTable_CellEndEdit);
            // 
            // LoadDefaults
            // 
            this.LoadDefaults.Location = new System.Drawing.Point(235, 353);
            this.LoadDefaults.Name = "LoadDefaults";
            this.LoadDefaults.Size = new System.Drawing.Size(125, 23);
            this.LoadDefaults.TabIndex = 15;
            this.LoadDefaults.Text = "Load Defaults (LS)";
            this.LoadDefaults.UseVisualStyleBackColor = true;
            this.LoadDefaults.Click += new System.EventHandler(this.button4_Click);
            // 
            // Help
            // 
            this.Help.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Help.Location = new System.Drawing.Point(124, 354);
            this.Help.Name = "Help";
            this.Help.Size = new System.Drawing.Size(50, 22);
            this.Help.TabIndex = 14;
            this.Help.Text = "Help";
            this.Help.UseVisualStyleBackColor = true;
            this.Help.Click += new System.EventHandler(this.button3_Click);
            // 
            // ApplyBonuses
            // 
            this.ApplyBonuses.Location = new System.Drawing.Point(27, 353);
            this.ApplyBonuses.Name = "ApplyBonuses";
            this.ApplyBonuses.Size = new System.Drawing.Size(75, 23);
            this.ApplyBonuses.TabIndex = 13;
            this.ApplyBonuses.Text = "Apply";
            this.ApplyBonuses.UseVisualStyleBackColor = true;
            this.ApplyBonuses.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Silver;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.Box7);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Controls.Add(this.Box6);
            this.panel3.Controls.Add(this.label12);
            this.panel3.Controls.Add(this.Box5);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.Box4);
            this.panel3.Controls.Add(this.label14);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.Box3);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.Box2);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.Box1);
            this.panel3.Controls.Add(this.label11);
            this.panel3.Location = new System.Drawing.Point(223, 47);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(151, 300);
            this.panel3.TabIndex = 11;
            // 
            // Box7
            // 
            this.Box7.Location = new System.Drawing.Point(100, 268);
            this.Box7.Name = "Box7";
            this.Box7.ReadOnly = true;
            this.Box7.Size = new System.Drawing.Size(36, 20);
            this.Box7.TabIndex = 17;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(11, 271);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(75, 13);
            this.label16.TabIndex = 16;
            this.label16.Text = "Total R Bonus";
            // 
            // Box6
            // 
            this.Box6.Location = new System.Drawing.Point(100, 234);
            this.Box6.Name = "Box6";
            this.Box6.ReadOnly = true;
            this.Box6.Size = new System.Drawing.Size(36, 20);
            this.Box6.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(11, 237);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(76, 13);
            this.label12.TabIndex = 14;
            this.label12.Text = "Total M Bonus";
            // 
            // Box5
            // 
            this.Box5.Location = new System.Drawing.Point(100, 184);
            this.Box5.Name = "Box5";
            this.Box5.ReadOnly = true;
            this.Box5.Size = new System.Drawing.Size(36, 20);
            this.Box5.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(11, 187);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "R Rig Bonus";
            // 
            // Box4
            // 
            this.Box4.Location = new System.Drawing.Point(100, 147);
            this.Box4.Name = "Box4";
            this.Box4.ReadOnly = true;
            this.Box4.Size = new System.Drawing.Size(36, 20);
            this.Box4.TabIndex = 11;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(11, 150);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "R Struc Bonus";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Bonus Decimal Amount";
            // 
            // Box3
            // 
            this.Box3.Location = new System.Drawing.Point(100, 111);
            this.Box3.Name = "Box3";
            this.Box3.ReadOnly = true;
            this.Box3.Size = new System.Drawing.Size(36, 20);
            this.Box3.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 114);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 4;
            this.label7.Text = "BP Bonus";
            // 
            // Box2
            // 
            this.Box2.Location = new System.Drawing.Point(100, 72);
            this.Box2.Name = "Box2";
            this.Box2.ReadOnly = true;
            this.Box2.Size = new System.Drawing.Size(36, 20);
            this.Box2.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(11, 75);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 13);
            this.label10.TabIndex = 2;
            this.label10.Text = "Rig Bonus";
            // 
            // Box1
            // 
            this.Box1.Location = new System.Drawing.Point(100, 35);
            this.Box1.Name = "Box1";
            this.Box1.ReadOnly = true;
            this.Box1.Size = new System.Drawing.Size(36, 20);
            this.Box1.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(11, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Structure Bonus";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Silver;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.ReactionRigBox);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.StructureReactionBox);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(20, 194);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(180, 153);
            this.panel2.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(94, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Reaction Bonuses";
            // 
            // ReactionRigBox
            // 
            this.ReactionRigBox.Location = new System.Drawing.Point(103, 97);
            this.ReactionRigBox.Name = "ReactionRigBox";
            this.ReactionRigBox.Size = new System.Drawing.Size(36, 20);
            this.ReactionRigBox.TabIndex = 3;
            this.ReactionRigBox.Leave += new System.EventHandler(this.ReactionRigBox_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(14, 100);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 13);
            this.label8.TabIndex = 2;
            this.label8.Text = "Rig Bonus";
            // 
            // StructureReactionBox
            // 
            this.StructureReactionBox.Location = new System.Drawing.Point(103, 60);
            this.StructureReactionBox.Name = "StructureReactionBox";
            this.StructureReactionBox.Size = new System.Drawing.Size(36, 20);
            this.StructureReactionBox.TabIndex = 1;
            this.StructureReactionBox.Leave += new System.EventHandler(this.StructureReactionBox_Leave);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 63);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 13);
            this.label9.TabIndex = 0;
            this.label9.Text = "Structure Bonus";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Silver;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.BluepringMEBox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.RigBonusBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.StructureBonusBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(20, 47);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(180, 144);
            this.panel1.TabIndex = 8;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Manufacturing Bonuses";
            // 
            // BluepringMEBox
            // 
            this.BluepringMEBox.Location = new System.Drawing.Point(103, 110);
            this.BluepringMEBox.Name = "BluepringMEBox";
            this.BluepringMEBox.Size = new System.Drawing.Size(36, 20);
            this.BluepringMEBox.TabIndex = 5;
            this.BluepringMEBox.Leave += new System.EventHandler(this.BluepringMEBox_Leave);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 113);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Blueprint ME";
            // 
            // RigBonusBox
            // 
            this.RigBonusBox.Location = new System.Drawing.Point(103, 71);
            this.RigBonusBox.Name = "RigBonusBox";
            this.RigBonusBox.Size = new System.Drawing.Size(36, 20);
            this.RigBonusBox.TabIndex = 3;
            this.RigBonusBox.Leave += new System.EventHandler(this.RigBonusBox_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Rig Bonus";
            // 
            // StructureBonusBox
            // 
            this.StructureBonusBox.Location = new System.Drawing.Point(103, 34);
            this.StructureBonusBox.Name = "StructureBonusBox";
            this.StructureBonusBox.Size = new System.Drawing.Size(36, 20);
            this.StructureBonusBox.TabIndex = 1;
            this.StructureBonusBox.Leave += new System.EventHandler(this.StructureBonusBox_Leave);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Structure Bonus";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.SalvageLoad);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1317, 660);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Component - Salvage";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // SalvageLoad
            // 
            this.SalvageLoad.Location = new System.Drawing.Point(6, 629);
            this.SalvageLoad.Name = "SalvageLoad";
            this.SalvageLoad.Size = new System.Drawing.Size(75, 23);
            this.SalvageLoad.TabIndex = 5;
            this.SalvageLoad.Text = "Load";
            this.SalvageLoad.UseVisualStyleBackColor = true;
            this.SalvageLoad.Click += new System.EventHandler(this.SalvageLoad_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 3);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 150;
            this.dataGridView1.Size = new System.Drawing.Size(1305, 620);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ReactionLoad);
            this.tabPage2.Controls.Add(this.dataGridView2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1317, 660);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Component - Reaction";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ReactionLoad
            // 
            this.ReactionLoad.Location = new System.Drawing.Point(6, 632);
            this.ReactionLoad.Name = "ReactionLoad";
            this.ReactionLoad.Size = new System.Drawing.Size(75, 23);
            this.ReactionLoad.TabIndex = 8;
            this.ReactionLoad.Text = "Load";
            this.ReactionLoad.UseVisualStyleBackColor = true;
            this.ReactionLoad.Click += new System.EventHandler(this.ReactionLoad_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(6, 6);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 150;
            this.dataGridView2.Size = new System.Drawing.Size(1305, 620);
            this.dataGridView2.TabIndex = 1;
            this.dataGridView2.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellEndEdit);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.dataGridView5);
            this.tabPage3.Controls.Add(this.ReactionReqLoad);
            this.tabPage3.Controls.Add(this.dataGridView3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1317, 660);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Reaction Requirements";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Location = new System.Drawing.Point(910, 3);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.ReadOnly = true;
            this.dataGridView5.RowHeadersWidth = 150;
            this.dataGridView5.Size = new System.Drawing.Size(401, 620);
            this.dataGridView5.TabIndex = 11;
            // 
            // ReactionReqLoad
            // 
            this.ReactionReqLoad.Location = new System.Drawing.Point(6, 631);
            this.ReactionReqLoad.Name = "ReactionReqLoad";
            this.ReactionReqLoad.Size = new System.Drawing.Size(75, 23);
            this.ReactionReqLoad.TabIndex = 10;
            this.ReactionReqLoad.Text = "Load";
            this.ReactionReqLoad.Click += new System.EventHandler(this.ReactionReqLoad_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(3, 3);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 150;
            this.dataGridView3.Size = new System.Drawing.Size(901, 620);
            this.dataGridView3.TabIndex = 2;
            this.dataGridView3.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellEndEdit);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.HullSubLoad);
            this.tabPage4.Controls.Add(this.dataGridView4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1317, 660);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Hull/Subsystem Reqs";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // HullSubLoad
            // 
            this.HullSubLoad.Location = new System.Drawing.Point(6, 629);
            this.HullSubLoad.Name = "HullSubLoad";
            this.HullSubLoad.Size = new System.Drawing.Size(75, 23);
            this.HullSubLoad.TabIndex = 10;
            this.HullSubLoad.Text = "Load";
            this.HullSubLoad.UseVisualStyleBackColor = true;
            this.HullSubLoad.Click += new System.EventHandler(this.HullSubLoad_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(3, 3);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.ReadOnly = true;
            this.dataGridView4.RowHeadersWidth = 150;
            this.dataGridView4.Size = new System.Drawing.Size(1305, 620);
            this.dataGridView4.TabIndex = 3;
            this.dataGridView4.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView4_CellEndEdit);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1350, 688);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "T3 Production - 2.1.1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ReactionRunsTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ReactionsTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MineralsTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SalvageTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GasTable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewT3Input)).EndInit();
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ComponentsOwnedTable)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dataGridViewT3Input;
        private System.Windows.Forms.DataGridView GasTable;
        private System.Windows.Forms.RichTextBox ItemsNeededBox;
        private System.Windows.Forms.DataGridView SalvageTable;
        private System.Windows.Forms.Button ReactionReqLoad;
        private System.Windows.Forms.Button HullSubLoad;
        private System.Windows.Forms.DataGridView MineralsTable;
        private System.Windows.Forms.DataGridView ReactionsTable;
        private System.Windows.Forms.Button Run;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridView ReactionRunsTable;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TextBox StructureBonusBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox Box5;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox Box4;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Box3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox Box2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox Box1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ReactionRigBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox StructureReactionBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox BluepringMEBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox RigBonusBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ApplyBonuses;
        private System.Windows.Forms.TextBox Box7;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox Box6;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Help;
        private System.Windows.Forms.Button LoadDefaults;
        private System.Windows.Forms.Button SalvageLoad;
        private System.Windows.Forms.Button ReactionLoad;
        private System.Windows.Forms.Button RunHelp;
        private System.Windows.Forms.DataGridView ComponentsOwnedTable;
        private System.Windows.Forms.Button CompHelp;
    }
}

