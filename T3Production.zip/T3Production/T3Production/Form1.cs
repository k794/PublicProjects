﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using Data = Google.Apis.Sheets.v4.Data;



namespace T3Production
{
    public partial class Form1 : Form
    {
        static SheetsService service;
        static string[] Scopes = { SheetsService.Scope.Spreadsheets };
        static string ApplicationName = "T3 Production API";
        static string[] dud = { "" };
        static string[] T3ColumnHeaders = { "Amount" };
        static string[] T3ReactionHeaders = { "Runs Needed", "Runs Completed" };
        static string[] T3ItemsNeededHeaders = { "Currently Needed", "Raw Needed", "Presently Owned" };
        static string[] Salvage = { "Ancient Radar Decorrelator", "Cartesian Temporal Coordinator", "Central System Controller", "Defensive Control Node", "Electromechanical Hull Sheeting", "Emergent Combat Analyzer", "Emergent Combat Intelligence", "Faraday Force Magnetometer", "Fused Nanomechanical Engines", "Heuristic Selfassemblers", "Jump Drive Control Nexus", "Melted Nanoribbons", "Modified Fluid Router", "Neurovisual Input Matrix", "Powdered C-540 Graphite", "Resonance Calibration Matrix", "Scorched Microgravimeter", "Synthetic Aperture Ladar Receiver", "Thermoelectric Catalysts" };
        static string[] Reactions = { "C3-FTM Acid", "Carbon-86 Epoxy Resin", "Fullerene Intercalated Graphite", "Fulleroferrocene", "Graphene Nanoribbons", "Lanthanum Metallofullerene", "Methanofullerene", "PPD Fullerene Fibers", "Scandium Metallofullerene" };
        static string[] Gas = { "Fullerite-C28", "Fullerite-C32", "Fullerite-C320", "Fullerite-C50", "Fullerite-C540", "Fullerite-C60", "Fullerite-C70", "Fullerite-C72", "Fullerite-C84" };
        static string[] T3Components = { "Electromechanical Interface Nexus", "Emergent Neurovisual Interface", "Fullerene Intercalated Sheets", "Fulleroferrocene Power Conduits", "Metallofullerene Plating", "Nanowire Composites", "Neurovisual Output Analyzer", "Optimized Nano-Engines", "Reconfigured Subspace Calibrator", "Reinforced Metallofullerene Alloys", "Self-Assembling Nanolattice", "Superconducting Gravimetric Amplifier", "Superconducting Ladar Amplifier", "Superconducting Magnetometric Amplifier", "Superconducting Radar Amplifier", "Warfare Computation Core" };
        static string[] Minerals = { "Isogen", "Megacyte", "Mexallon", "Morphite", "Nocxium", "Pyerite", "Tritanium", "Zydrine" };
        static string[] FuelBlock = { "Helium Fuel Block", "Hydrogen Fuel Block", "Nitrogen Fuel Block", "Oxygen Fuel Block" };
        static string[] T3D = { "Confessor", "Svipul", "Jackdaw", "Hecate" };
        static string[] T3C = { "Legion", "Loki", "Tengu", "Proteus" };
        static string[] Subsystem = { "Legion Core - Augmented Antimatter Reactor", "Legion Core - Dissolution Sequencer", "Legion Core - Energy Parasitic Complex", "Legion Defensive - Covert Reconfiguration", "Legion Defensive - Augmented Plating", "Legion Defensive - Nanobot Injector", "Legion Offensive - Assault Optimization", "Legion Offensive - Liquid Crystal Magnifiers", "Legion Offensive - Support Processor", "Legion Propulsion - Intercalated Nanofibers", "Legion Propulsion - Interdiction Nullifier", "Legion Propulsion - Wake Limiter", "Loki Core - Augmented Nuclear Reactor", "Loki Core - Dissolution Sequencer", "Loki Core - Immobility Drivers", "Loki Defensive - Covert Reconfiguration", "Loki Defensive - Adaptive Defense Node", "Loki Defensive - Augmented Durability", "Loki Offensive - Launcher Efficiency Configuration", "Loki Offensive - Projectile Scoping Array", "Loki Offensive - Support Processor", "Loki Propulsion - Intercalated Nanofibers", "Loki Propulsion - Interdiction Nullifier", "Loki Propulsion - Wake Limiter", "Tengu Core - Augmented Graviton Reactor", "Tengu Core - Electronic Efficiency Gate", "Tengu Core - Obfuscation Manifold", "Tengu Defensive - Covert Reconfiguration", "Tengu Defensive - Amplification Node", "Tengu Defensive - Supplemental Screening", "Tengu Offensive - Accelerated Ejection Bay", "Tengu Offensive - Magnetic Infusion Basin", "Tengu Offensive - Support Processor", "Tengu Propulsion - Interdiction Nullifier", "Proteus Core - Augmented Fusion Reactor", "Proteus Core - Electronic Efficiency Gate", "Proteus Core - Friction Extension Processor", "Proteus Defensive - Covert Reconfiguration", "Proteus Defensive - Augmented Plating", "Proteus Defensive - Nanobot Injector", "Proteus Offensive - Drone Synthesis Projector", "Proteus Offensive - Hybrid Encoding Platform", "Proteus Offensive - Support Processor", "Proteus Propulsion - Hyperspatial Optimization", "Proteus Propulsion - Interdiction Nullifier", "Proteus Propulsion - Localized Injectors" };
        static string[] T3Type = { "Destroyer Hull", "Legion", "Loki", "Tengu", "Proteus", "Subsytem Set", "Core", "Defensive", "Offensive", "Propulsion" };
        static string[] CombinedT3Names = { "T3Ds", "Legion", "Loki", "Tengu", "Proteus", "Subsytem Sets" };
        static string[] CombinedT3Mats = {"Fullerite-C28", "Fullerite-C32", "Fullerite-C320", "Fullerite-C50", "Fullerite-C540", "Fullerite-C60", "Fullerite-C70", "Fullerite-C72", "Fullerite-C84" ,"Ancient Radar Decorrelator", "Cartesian Temporal Coordinator", "Central System Controller", "Defensive Control Node", "Electromechanical Hull Sheeting", "Emergent Combat Analyzer", "Emergent Combat Intelligence", "Faraday Force Magnetometer", "Fused Nanomechanical Engines", "Heuristic Selfassemblers", "Jump Drive Control Nexus", "Melted Nanoribbons", "Modified Fluid Router", "Neurovisual Input Matrix", "Powdered C-540 Graphite", "Resonance Calibration Matrix", "Scorched Microgravimeter", "Synthetic Aperture Ladar Receiver", "Thermoelectric Catalysts", "Isogen", "Megacyte", "Mexallon", "Morphite", "Nocxium", "Pyerite", "Tritanium", "Zydrine" };
        static string[] CombinedGasMinerals = { "Fullerite-C28", "Fullerite-C32", "Fullerite-C320", "Fullerite-C50", "Fullerite-C540", "Fullerite-C60", "Fullerite-C70", "Fullerite-C72", "Fullerite-C84", "Isogen", "Megacyte", "Mexallon", "Morphite", "Nocxium", "Pyerite", "Tritanium", "Zydrine" };

        static double[] ComponentsNeeded = new double[16];
        static double[] ReactionsNeeded = new double[9];
        static double[] ReactionRunsNeeded = new double[9];
        static double[] SalvageNeeded = new double[19];
        static double[] GasNeeded = new double[9];
        static double[] MineralsNeeded = new double[8];
        static double[] FuelBlocksNeeded = new double[4];

        static double MStructureBonus = .99;
        static double MStructureRig = .962;
        static double MBlueprintME = .9;
        static double RStructureBonus = 1;
        static double RStructureRig = .98;
        static double TotalMBonus = 1;
        static double TotalRBonus = 1;

        static double DMStructureBonus = .99;
        static double DMStructureRig = .962;
        static double DMBlueprintME = .9;
        static double DRStructureBonus = 1;
        static double DRStructureRig = .98;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Authenticate();

            MStructureBonus = T3Production.Properties.Settings.Default.MStrucB;
            MStructureRig = T3Production.Properties.Settings.Default.MRigB;
            MBlueprintME = T3Production.Properties.Settings.Default.MbpB;
            RStructureBonus = T3Production.Properties.Settings.Default.RStrucB;
            RStructureRig = T3Production.Properties.Settings.Default.RRigB;
            TotalMBonus = T3Production.Properties.Settings.Default.MTotal;
            TotalRBonus = T3Production.Properties.Settings.Default.RTotal;

            Box3.Text = MBlueprintME.ToString();
            Box1.Text = MStructureBonus.ToString();
            Box2.Text = MStructureRig.ToString();
            Box4.Text = RStructureBonus.ToString();
            Box5.Text = RStructureRig.ToString();
            Box6.Text = TotalMBonus.ToString();
            Box7.Text = TotalRBonus.ToString();

            PopulateTables(ref dataGridView1, 70, Salvage, dud, T3Components);
            PopulateTables(ref dataGridView2, 70, Reactions, dud, T3Components);
            PopulateTables(ref dataGridView3, 70, CombinedGasMinerals, FuelBlock, Reactions);
            PopulateTables(ref dataGridView4, 70, T3Type, dud, T3Components);
            PopulateTables(ref dataGridView5, 70, Reactions, dud, T3ColumnHeaders);

            PopulateTables(ref dataGridViewT3Input, 70, CombinedT3Names, dud, T3ColumnHeaders);
            PopulateTables(ref GasTable, 52, Gas, dud, T3ItemsNeededHeaders);
            PopulateTables(ref SalvageTable, 52, Salvage, dud, T3ItemsNeededHeaders);
            PopulateTables(ref MineralsTable, 52, Minerals, dud, T3ItemsNeededHeaders);
            PopulateTables(ref ReactionsTable, 52, Reactions, dud, T3ItemsNeededHeaders);
            PopulateTables(ref ReactionRunsTable, 52, Reactions, dud, T3ReactionHeaders);
            PopulateTables(ref ComponentsOwnedTable, 53, T3Components, dud, T3ItemsNeededHeaders);

            LoadsSomeBullshit(ref dataGridView1, service, "Component - Salvage!A1:P19", true);
            LoadsSomeBullshit(ref dataGridView2, service, "Component - Reaction!A1:P9", true);
            LoadsSomeBullshit(ref dataGridView3, service, "Reaction Requirements!A1:I21", true);
            LoadsSomeBullshit(ref dataGridView4, service, "Hull/Subsystem Reqs2!A1:P10", true);
            LoadsSomeBullshit(ref dataGridViewT3Input, service, "T3Inputs!A1:A6", false);
            LoadsSomeBullshit(ref dataGridView5, service, "Reaction Requirements!A24:A32", false);

            LoadsSomeBullshit2(ref GasTable, service, "Current Mats!C1:C9", false, 2);
            LoadsSomeBullshit2(ref MineralsTable, service, "Current Mats!F1:F8", false, 2);
            LoadsSomeBullshit2(ref SalvageTable, service, "Current Mats!I1:I19", false, 2);
            LoadsSomeBullshit2(ref ReactionsTable, service, "Current Mats!L1:L9", false, 2);
            LoadsSomeBullshit2(ref ReactionRunsTable, service, "Current Mats!N1:N9", false, 1);
            LoadsSomeBullshit2(ref ComponentsOwnedTable, service, "Current Mats!O1:Q16", false, 2);

            GasTable.Columns[0].ReadOnly = true;
            GasTable.Columns[1].ReadOnly = true;
            SalvageTable.Columns[0].ReadOnly = true;
            SalvageTable.Columns[1].ReadOnly = true;
            MineralsTable.Columns[0].ReadOnly = true;
            MineralsTable.Columns[1].ReadOnly = true;
            ReactionsTable.Columns[0].ReadOnly = true;
            ReactionsTable.Columns[1].ReadOnly = true;
            ReactionRunsTable.Columns[0].ReadOnly = true;

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            T3Production.Properties.Settings.Default.MStrucB = MStructureBonus;
            T3Production.Properties.Settings.Default.MRigB = MStructureRig;
            T3Production.Properties.Settings.Default.MbpB = MBlueprintME;
            T3Production.Properties.Settings.Default.RStrucB = RStructureBonus;
            T3Production.Properties.Settings.Default.RRigB = RStructureRig;
            T3Production.Properties.Settings.Default.MTotal = TotalMBonus;
            T3Production.Properties.Settings.Default.RTotal = TotalRBonus;

            T3Production.Properties.Settings.Default.Save();

            WritesSomeBullshit(ref GasTable, service, "Current Mats!A1:C9");
            WritesSomeBullshit(ref MineralsTable, service, "Current Mats!D1:F8");
            WritesSomeBullshit(ref SalvageTable, service, "Current Mats!G1:I19");
            WritesSomeBullshit(ref ReactionsTable, service, "Current Mats!J1:L9");
            WritesSomeBullshit(ref ReactionRunsTable, service, "Current Mats!M1:N9");
            WritesSomeBullshit(ref ComponentsOwnedTable, service, "Current Mats!O1:Q16");
        }

        public static void Authenticate()
        {
            UserCredential credential;
            string test = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
            string cred = "credentials.json";
            using (var stream =
                new FileStream(Path.Combine(test, cred), FileMode.Open, FileAccess.Read))
            {
                credential = GoogleWebAuthorizationBroker.AuthorizeAsync(
                    GoogleClientSecrets.Load(stream).Secrets,
                    Scopes,
                    "user",
                    CancellationToken.None,
                    new FileDataStore(test, true)).Result;              
                Console.WriteLine(test);
            }
            // Create Google Sheets API service.
            service = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
        }

        public static void LoadsSomeBullshit(ref DataGridView dataGridView, SheetsService service, String range, bool colorCondition)
        {
            // Define request parameters.
            String spreadsheetId = "1A9sFmd6M5IqiedjkP_N_Vaypsecu1m4-wSRWi82dk9Y";
            SpreadsheetsResource.ValuesResource.GetRequest request =
                    service.Spreadsheets.Values.Get(spreadsheetId, range);
            
            ValueRange response = request.Execute();

            IList<IList<Object>> values = response.Values;

            int indexRow = 0;
            foreach (var row in values)
            {
                int indexColumn = 0;
                foreach (var obj in row)
                {
                    dataGridView.Rows[indexRow].Cells[indexColumn].Value = obj;
                    if (dataGridView.Rows[indexRow].Cells[indexColumn].Value.ToString() != "0" && colorCondition == true)
                    {
                        dataGridView.Rows[indexRow].Cells[indexColumn].Style.BackColor = System.Drawing.Color.Gray;
                    }
                    indexColumn++;
                }
                indexRow++;
            }
        }

        public static void LoadsSomeBullshit2(ref DataGridView dataGridView, SheetsService service, String range, bool colorCondition, int colNum)
        {
            // Define request parameters.
            String spreadsheetId = "1A9sFmd6M5IqiedjkP_N_Vaypsecu1m4-wSRWi82dk9Y";
            SpreadsheetsResource.ValuesResource.GetRequest request =
                    service.Spreadsheets.Values.Get(spreadsheetId, range);

            ValueRange response = request.Execute();

            IList<IList<Object>> values = response.Values;

            int indexRow = 0;
            foreach (var row in values)
            {
                int indexColumn = colNum;
                foreach (var obj in row)
                {
                    dataGridView.Rows[indexRow].Cells[indexColumn].Value = obj;
                    if (dataGridView.Rows[indexRow].Cells[indexColumn].Value.ToString() != "0" && colorCondition == true)
                    {
                        dataGridView.Rows[indexRow].Cells[indexColumn].Style.BackColor = System.Drawing.Color.Gray;
                    }
                    //indexColumn++;
                }
                indexRow++;
            }
        }

        public static void WritesSomeBullshit(ref DataGridView dataGridView, SheetsService service, String range2)
        {
            // Define request parameters.
            String spreadsheetId2 = "1A9sFmd6M5IqiedjkP_N_Vaypsecu1m4-wSRWi82dk9Y";

            ValueRange valueRange = new ValueRange();
            valueRange.MajorDimension = "COLUMNS";//"ROWS";//COLUMNS

            List<IList<Object>> test = new List<IList<object>>();


            foreach (DataGridViewColumn col in dataGridView.Columns)
            {
                int index = col.Index;
                var oblist = new List<object>();
                oblist = dataGridView.Rows
                                 .OfType<DataGridViewRow>()
                                 .Select(r => r.Cells[index].Value)
                                 .ToList();
                test.Add(oblist);
            }


            valueRange.Values = test;

            SpreadsheetsResource.ValuesResource.UpdateRequest update = service.Spreadsheets.Values.Update(valueRange, spreadsheetId2, range2);
            update.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
            UpdateValuesResponse result2 = update.Execute();
        }

        public static void PopulateTables(ref DataGridView CurrentDataGrid, int colWidth, string [] row, string [] row2, string [] col)
        {
            CurrentDataGrid.RowTemplate.Height = 30;
          
            int colNum = 0;
            foreach (var item in col)
            {
                CurrentDataGrid.Columns.Add(item, item);
                DataGridViewColumn column = CurrentDataGrid.Columns[colNum];
                column.Width = colWidth;
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
                colNum++;
            }

            int rowNum = 0;
            foreach (var item in row)
            {
                CurrentDataGrid.Rows.Add();
                CurrentDataGrid.Rows[rowNum].HeaderCell.Value = item;
                rowNum++;
            }
            if (row2[0] != "")
            {
                foreach (var item in row2)
                {
                    CurrentDataGrid.Rows.Add();
                    CurrentDataGrid.Rows[rowNum].HeaderCell.Value = item;
                    rowNum++;
                }
            }

            CurrentDataGrid.AllowUserToAddRows = false;
            
            for (int c = 0; c < CurrentDataGrid.ColumnCount; c++)
            {
                for (int r = 0; r < CurrentDataGrid.RowCount; r++)
                {
                    CurrentDataGrid.Rows[r].Cells[c].Value = 0;
                }
            }
        }

        static public void CalculateComponents(ref DataGridView T3Input, ref DataGridView ComponentsRef, ref DataGridView Owned)
        {
            for (int i = 0; ComponentsNeeded.Length > i; i++) //Resets the array
            {
                ComponentsNeeded[i] = 0;
            }
            for (int col = 0; ComponentsRef.Columns.Count > col; col++)
            {
                for (int i = 0; i < 6; i++)
                {
                    ComponentsNeeded[col] += double.Parse(T3Input.Rows[i].Cells[0].Value.ToString()) * double.Parse(ComponentsRef.Rows[i].Cells[col].Value.ToString());

                }
            }
            for (int i = 0; ComponentsNeeded.Length > i; i++)
            {
                Owned.Rows[i].Cells[1].Value = ComponentsNeeded[i];
                double val = ComponentsNeeded[i] - double.Parse(Owned.Rows[i].Cells[2].Value.ToString());
                if (val < 0)
                {
                    ComponentsNeeded[i] = 0;
                }
                else
                {
                    ComponentsNeeded[i] = val;
                }
                Owned.Rows[i].Cells[0].Value = ComponentsNeeded[i];
                Console.WriteLine("Component: " + ComponentsNeeded[i]);

            }
        }

        static public void CalculateReactions(ref DataGridView ReactionsRaw, ref DataGridView ReactionsOutput, double bonus)
        {
            for (int i = 0; ReactionsNeeded.Length > i; i++) //Resets the array
            {
                ReactionsNeeded[i] = 0;
            }
            for (int i = 0; ReactionsNeeded.Length > i; i++)
            {
                for (int j = 0; ReactionsRaw.Columns.Count > j; j++)
                {
                    ReactionsNeeded[i] += double.Parse(ComponentsNeeded[j].ToString()) * double.Parse(ReactionsRaw.Rows[i].Cells[j].Value.ToString());
                    Console.WriteLine(ComponentsNeeded[j] +" :: " +  ReactionsRaw.Rows[i].Cells[j].Value.ToString());
                }
                ReactionsNeeded[i] = Math.Ceiling(((ReactionsNeeded[i]* bonus) / 10) * 10);               
            }
            for (int i = 0; ReactionsOutput.Rows.Count > i; i++)
            {
                double val = ReactionsNeeded[i] - double.Parse(ReactionsOutput.Rows[i].Cells[2].Value.ToString());
                if (val < 0)
                {
                    ReactionsOutput.Rows[i].Cells[0].Value = 0;
                    ReactionsNeeded[i] = 0;
                    ReactionsOutput.Rows[i].Cells[1].Value = ReactionsNeeded[i];
                }
                else
                {
                    ReactionsOutput.Rows[i].Cells[0].Value = val;
                    ReactionsNeeded[i] = val;
                    ReactionsOutput.Rows[i].Cells[1].Value = ReactionsNeeded[i];
                }
            }
        }

        static public void CalculateSalvage(ref DataGridView SalvageRaw, ref DataGridView SalvageOutput, double bonus)
        {
            for (int i = 0; SalvageNeeded.Length > i; i++)
            {
                SalvageNeeded[i] = 0;
            }
            for (int i = 0; SalvageNeeded.Length > i; i++)
            {
                for (int j = 0; SalvageRaw.Columns.Count > j; j++)
                {
                    SalvageNeeded[i] += double.Parse(ComponentsNeeded[j].ToString()) * double.Parse(SalvageRaw.Rows[i].Cells[j].Value.ToString());
                }
            }
            for (int i = 0; SalvageOutput.Rows.Count > i; i++)
            {
                if (i == 2 || i == 3 || i == 6 || i == 10 || i == 18)
                {
                    double val = Math.Ceiling((SalvageNeeded[i]) / 10) * 10;
                    SalvageOutput.Rows[i].Cells[1].Value = val;
                    SalvageOutput.Rows[i].Cells[0].Value = val;
                    SalvageNeeded[i] = val;
                }
                else
                {
                    double val = Math.Ceiling((SalvageNeeded[i] * bonus) / 10) * 10;
                    SalvageOutput.Rows[i].Cells[1].Value = val;
                    SalvageOutput.Rows[i].Cells[0].Value = val;
                    SalvageNeeded[i] = val;
                }            
            }
        }

        static public void CalculateReactionRuns( ref DataGridView MineralsOutput, ref DataGridView GasOutput, ref DataGridView ReactionsRaw, ref DataGridView UnitsPer, ref DataGridView ReactionsOutput, double bonus)
        {
            for (int i = 0; ReactionRunsNeeded.Length > i; i++)
            {
                ReactionRunsNeeded[i] = 0;
            }
            for (int i = 0; Minerals.Length > i; i++)
            {
                MineralsNeeded[i] = 0;
            }
            for (int i = 0; GasNeeded.Length > i; i++)
            {
                GasNeeded[i] = 0;
            }
            for (int i = 0; FuelBlocksNeeded.Length > i; i++)
            {
                FuelBlocksNeeded[i] = 0;
            }
            for (int i = 0; ReactionRunsNeeded.Length > i; i++)
            {
                double runs = Math.Ceiling(ReactionsNeeded[i] / double.Parse(UnitsPer.Rows[i].Cells[0].Value.ToString()));
                ReactionRunsNeeded[i] = runs;
                ReactionsOutput.Rows[i].Cells[0].Value = runs;
            }

            for (int i = 0; ReactionRunsNeeded.Length > i; i++)
            {
                int g = 0;
                int m = 0;
                int f = 0;
                for (int j = 0; ReactionsRaw.Rows.Count > j; j++)
                {
                    if (j < 9)
                    {
                        GasNeeded[g] += ReactionRunsNeeded[i] * Math.Ceiling(double.Parse(ReactionsRaw.Rows[j].Cells[i].Value.ToString())*bonus);
                        g++;
                    }
                    else if ( j < 17)
                    {
                        MineralsNeeded[m] += ReactionRunsNeeded[i] * double.Parse(ReactionsRaw.Rows[j].Cells[i].Value.ToString());
                        m++;
                    }
                    else
                    {
                        FuelBlocksNeeded[f] += ReactionRunsNeeded[i] * double.Parse(ReactionsRaw.Rows[j].Cells[i].Value.ToString());
                        f++;
                    }                                                      
                }
            }
            for (int i = 0; GasNeeded.Length > i; i++)
            {
                GasOutput.Rows[i].Cells[1].Value = GasNeeded[i];
                GasOutput.Rows[i].Cells[0].Value = GasNeeded[i];
                Console.WriteLine(GasNeeded[i]);
            }
            for (int i = 0; MineralsNeeded.Length > i; i++)
            {
                MineralsOutput.Rows[i].Cells[1].Value = MineralsNeeded[i];
                MineralsOutput.Rows[i].Cells[0].Value = MineralsNeeded[i];
                Console.WriteLine(MineralsNeeded[i]);
            }
            for (int i = 0; FuelBlocksNeeded.Length > i; i++)
            {
                Console.WriteLine(FuelBlocksNeeded[i]);
            }

        }

        public static void UpdateOutputBox(RichTextBox box, ref DataGridView gas, ref DataGridView minerals, ref DataGridView salvage)
        {
            box.Clear();

            for (int i = 0; salvage.Rows.Count > i; i++)
            {
                if (salvage.Rows[i].Cells[0].Value.ToString() != "0")
                {
                    box.AppendText(Salvage[i] + " " + salvage.Rows[i].Cells[0].Value + "\n");
                }               
            }
            for (int i = 0; gas.Rows.Count > i; i++)
            {
                if (gas.Rows[i].Cells[0].Value.ToString() != "0")
                {
                    box.AppendText(Gas[i] + " " + gas.Rows[i].Cells[0].Value + "\n");
                }               
            }
            for (int i = 0; minerals.Rows.Count > i; i++)
            {
                if (minerals.Rows[i].Cells[0].Value.ToString() != "0")
                {
                    box.AppendText(Minerals[i] + " " + minerals.Rows[i].Cells[0].Value + "\n");
                }                
            }
            for (int i = 0; FuelBlocksNeeded.Length > i; i++)
            {
                box.AppendText(FuelBlock[i] + " " + FuelBlocksNeeded[i] + "\n");
            }
        }

        static public void UpdateItemsNeeded(ref DataGridView Gas, ref DataGridView Minerals, ref DataGridView Salvage)
        {           
            for (int row = 0; Gas.Rows.Count > row; row++)
            {
                double val = double.Parse(Gas.Rows[row].Cells[1].Value.ToString()) - double.Parse(Gas.Rows[row].Cells[2].Value.ToString());
                if ( val >= 0)
                {
                    Gas.Rows[row].Cells[0].Value = val;
                }
                else
                {
                    Gas.Rows[row].Cells[0].Value = 0;
                }
            }
            for (int row = 0; Salvage.Rows.Count > row; row++)
            {
                double val = double.Parse(Salvage.Rows[row].Cells[1].Value.ToString()) - double.Parse(Salvage.Rows[row].Cells[2].Value.ToString());
                if (val >= 0)
                {
                    Salvage.Rows[row].Cells[0].Value = val;
                }
                else
                {
                    Salvage.Rows[row].Cells[0].Value = 0;
                }
            }
            for (int row = 0; Minerals.Rows.Count > row; row++)
            {
                double val = double.Parse(Minerals.Rows[row].Cells[1].Value.ToString()) - double.Parse(Minerals.Rows[row].Cells[2].Value.ToString());
                if (val >= 0)
                {
                    Minerals.Rows[row].Cells[0].Value = val;
                }
                else
                {
                    Minerals.Rows[row].Cells[0].Value = 0;
                }
            }
        }

        private void SalvageLoad_Click(object sender, EventArgs e)
        {
            LoadsSomeBullshit(ref dataGridView1, service, "Component - Salvage!A1:P19", true);
        }

        private void ReactionLoad_Click(object sender, EventArgs e)
        {
            LoadsSomeBullshit(ref dataGridView2, service, "Component - Reaction!A1:P9", true);
        }

        private void ReactionReqLoad_Click(object sender, EventArgs e)
        {
            LoadsSomeBullshit(ref dataGridView3, service, "Reaction Requirements!A1:I21", true);
        }

        private void HullSubLoad_Click(object sender, EventArgs e)
        {
            LoadsSomeBullshit(ref dataGridView4, service, "Hull/Subsystem Reqs2!A1:P10", true);
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; dataGridView1.Columns.Count > col; col++)
            {
                for (int row = 0; dataGridView1.Rows.Count > row; row++)
                {
                    if (dataGridView1.Rows[row].Cells[col].Value.ToString() != "0")
                    {
                        dataGridView1.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.Gray;
                    }
                    else
                    {
                        dataGridView1.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.White;
                    }
                }
            }
        }

        private void dataGridView2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; dataGridView2.Columns.Count > col; col++)
            {
                for (int row = 0; dataGridView2.Rows.Count > row; row++)
                {
                    if (dataGridView2.Rows[row].Cells[col].Value.ToString() != "0")
                    {
                        dataGridView2.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.Gray;
                    }
                    else
                    {
                        dataGridView2.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.White;
                    }
                }
            }
        }

        private void dataGridView3_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; dataGridView3.Columns.Count > col; col++)
            {
                for (int row = 0; dataGridView3.Rows.Count > row; row++)
                {
                    if (dataGridView3.Rows[row].Cells[col].Value.ToString() != "0")
                    {
                        dataGridView3.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.Gray;
                    }
                    else
                    {
                        dataGridView3.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.White;
                    }
                }
            }
        }

        private void dataGridView4_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int col = 0; dataGridView4.Columns.Count > col; col++)
            {
                for (int row = 0; dataGridView4.Rows.Count > row; row++)
                {
                    if (dataGridView4.Rows[row].Cells[col].Value.ToString() != "0")
                    {
                        dataGridView4.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.Gray;
                    }
                    else
                    {
                        dataGridView4.Rows[row].Cells[col].Style.BackColor = System.Drawing.Color.White;
                    }
                }
            }
        }

        private void dataGridViewT3Input_CellEndEdit_1(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = 0; dataGridViewT3Input.Rows.Count > i; i++)
            {
                if (!int.TryParse(dataGridViewT3Input.Rows[i].Cells[0].Value.ToString(), out int val))
                {
                    dataGridViewT3Input.Rows[i].Cells[0].Value = 0;
                    WritesSomeBullshit(ref dataGridViewT3Input, service, "T3Inputs!A1:A9");
                }
                else
                {
                    WritesSomeBullshit(ref dataGridViewT3Input, service, "T3Inputs!A1:A9");
                }
            }
        }

        private void StructureBonusBox_Leave(object sender, EventArgs e)
        {
            if(!double.TryParse(StructureBonusBox.Text, out double b))
            {
                StructureBonusBox.Text = "No Value Set";
                MStructureBonus = 1;
            }
            else
            {
                MStructureBonus = (100 - b) / 100;
            }
        }

        private void RigBonusBox_Leave(object sender, EventArgs e)
        {
            if (!double.TryParse(RigBonusBox.Text, out double b))
            {
                RigBonusBox.Text = "No Value Set";
                MStructureRig = 1;
            }
            else
            {
                MStructureRig = (100 - b) / 100;
            }
        }

        private void BluepringMEBox_Leave(object sender, EventArgs e)
        {
            if (!double.TryParse(BluepringMEBox.Text, out double b))
            {
                BluepringMEBox.Text = "No Value Set";
                MBlueprintME = 1;
            }
            else
            {
                MBlueprintME = (100 - b) / 100;
            }
        }

        private void StructureReactionBox_Leave(object sender, EventArgs e)
        {
            if (!double.TryParse(StructureReactionBox.Text, out double b))
            {
                StructureBonusBox.Text = "No Value Set";
                RStructureBonus = 1;
            }
            else
            {                
                RStructureBonus = (100 - b) / 100;
            }
        }

        private void ReactionRigBox_Leave(object sender, EventArgs e)
        {
            if (!double.TryParse(ReactionRigBox.Text, out double b))
            {
                ReactionRigBox.Text = "No Value Set";
                RStructureRig = 1;
            }
            else
            {
                RStructureRig = (100 - b) / 100;
            }
        }

        private void dataGridViewMatsNeeded_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = 0; GasTable.Rows.Count > i; i++)
            {
                if (!int.TryParse(GasTable.Rows[i].Cells[2].Value.ToString(), out int val))
                {
                    GasTable.Rows[i].Cells[2].Value = 0;
                }
                else
                {
                    GasTable.Rows[i].Cells[2].Value = val;
                }
            }

            UpdateItemsNeeded(ref GasTable, ref MineralsTable, ref SalvageTable);
            UpdateOutputBox(ItemsNeededBox, ref GasTable, ref MineralsTable, ref SalvageTable);
        }

        private void dataGridViewMinerals_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = 0; MineralsTable.Rows.Count > i; i++)
            {
                if (!int.TryParse(MineralsTable.Rows[i].Cells[2].Value.ToString(), out int val))
                {
                    MineralsTable.Rows[i].Cells[2].Value = 0;
                }
                else
                {
                    MineralsTable.Rows[i].Cells[2].Value = val;
                }
            }
            UpdateItemsNeeded(ref GasTable, ref MineralsTable, ref SalvageTable);
            UpdateOutputBox(ItemsNeededBox, ref GasTable, ref MineralsTable, ref SalvageTable);
        }

        private void dataGridViewMatsNeeded2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = 0; SalvageTable.Rows.Count > i; i++)
            {
                if (!int.TryParse(SalvageTable.Rows[i].Cells[2].Value.ToString(), out int val))
                {
                    SalvageTable.Rows[i].Cells[2].Value = 0;
                }
                else
                {
                    SalvageTable.Rows[i].Cells[2].Value = val;
                }
            }
            UpdateItemsNeeded(ref GasTable, ref MineralsTable, ref SalvageTable);
            UpdateOutputBox(ItemsNeededBox, ref GasTable, ref MineralsTable, ref SalvageTable);
        }

        private void ComponentsOwnedTable_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = 0; ComponentsOwnedTable.Rows.Count > i; i++)
            {
                if (!int.TryParse(ComponentsOwnedTable.Rows[i].Cells[0].Value.ToString(), out int val))
                {
                    ComponentsOwnedTable.Rows[i].Cells[0].Value = 0;
                }
                else
                {
                    ComponentsOwnedTable.Rows[i].Cells[0].Value = val;
                }
            }
        }

        private void ReactionRunsTable_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            for (int i = 0; ReactionRunsTable.Rows.Count > i; i++)
            {
                if (!int.TryParse(ReactionRunsTable.Rows[i].Cells[0].Value.ToString(), out int val))
                {
                    ReactionRunsTable.Rows[i].Cells[0].Value = 0;
                }
                else
                {
                    ReactionRunsTable.Rows[i].Cells[0].Value = val;
                }
            }
            WritesSomeBullshit(ref ReactionRunsTable, service, "Current Mats!M1:N9");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool runCondition = true;
            for (int row = 0; ComponentsOwnedTable.Rows.Count > row; row++)
            {
                if (ComponentsOwnedTable.Rows[row].Cells[2].Value.ToString() != "0")
                {
                    runCondition = false;
                }
            }
            if (runCondition == false)
            {
                MessageBox.Show("Warning! Values are entered in the components owned table on the second tab. Make sure that this is correct.");
            }

            CalculateComponents(ref dataGridViewT3Input, ref dataGridView4, ref ComponentsOwnedTable);
            CalculateReactions(ref dataGridView2, ref ReactionsTable, TotalMBonus);
            CalculateSalvage(ref dataGridView1, ref SalvageTable, TotalMBonus);
            CalculateReactionRuns(ref MineralsTable, ref GasTable, ref dataGridView3, ref dataGridView5, ref ReactionRunsTable, TotalRBonus);
            UpdateItemsNeeded(ref GasTable, ref MineralsTable, ref SalvageTable);
            UpdateOutputBox(ItemsNeededBox, ref GasTable, ref MineralsTable, ref SalvageTable);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (StructureBonusBox.Text == "" || BluepringMEBox.Text == "" || RigBonusBox.Text == "" || StructureReactionBox.Text == "" || ReactionRigBox.Text == "")
            {
                MessageBox.Show("Invalid input. Please Try again");
            }
            else
            {
                TotalMBonus = Math.Floor((MStructureRig * MStructureBonus * MBlueprintME) * 1000) / 1000;
                TotalRBonus = Math.Floor((RStructureRig * RStructureBonus) * 1000) / 1000;

                Box3.Text = MBlueprintME.ToString();
                Box1.Text = MStructureBonus.ToString();
                Box2.Text = MStructureRig.ToString();
                Box4.Text = RStructureBonus.ToString();
                Box5.Text = RStructureRig.ToString();
                Box6.Text = TotalMBonus.ToString();
                Box7.Text = TotalRBonus.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enter bonuses as their base bonus value or ME level. \nFor example, 10 for a ME 10 blueprint, or 4.2 for a 4.2% bonus on a rig.\nEnter a 0 if there is to be no bonus\n\nThe calculated values will appear on the right - They are read only\n\nIf you have any questions, contact Random");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            T3Production.Properties.Settings.Default.MStrucB = DMStructureBonus;
            T3Production.Properties.Settings.Default.MRigB = DMStructureRig;
            T3Production.Properties.Settings.Default.MbpB = DMBlueprintME;
            T3Production.Properties.Settings.Default.RStrucB = DRStructureBonus;
            T3Production.Properties.Settings.Default.RRigB = DRStructureRig;

            MStructureBonus = DMStructureBonus;
            MStructureRig = DMStructureRig;
            MBlueprintME = DMBlueprintME;
            RStructureBonus = DRStructureBonus;
            RStructureRig = DRStructureRig;

            TotalMBonus = Math.Floor((DMStructureRig * DMStructureBonus * DMBlueprintME) * 1000) / 1000;
            TotalRBonus = Math.Floor((DRStructureRig * DRStructureBonus) * 1000) / 1000;

            T3Production.Properties.Settings.Default.MTotal = TotalMBonus;
            T3Production.Properties.Settings.Default.RTotal = TotalRBonus;

            Box1.Text = DMStructureBonus.ToString();
            Box2.Text = DMStructureRig.ToString();
            Box3.Text = DMBlueprintME.ToString();
            Box4.Text = DRStructureBonus.ToString();
            Box5.Text = DRStructureRig.ToString();
            Box6.Text = TotalMBonus.ToString();
            Box7.Text = TotalRBonus.ToString();

            T3Production.Properties.Settings.Default.Save();
            MessageBox.Show("Default settings for low sec loaded.\nProperties have been saved to your program and persist between uses.");
        }

        private void RunHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Pressing run will do the following\n1) Print current T3 input values to sheet\n2) Re-Calculate the mats needed\n3) Adjust parameters for current inventory of reactions. All other mats will live update.");
        }

        private void CompHelp_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enter values here for components that are already owned.\n\nThese values do not persist between uses and will generate a warning when you press run on the main screen.");
        }
    }
}
