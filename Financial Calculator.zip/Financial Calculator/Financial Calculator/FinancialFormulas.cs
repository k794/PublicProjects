﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Financial_Calculator
{
    class FinancialFormulas
    {
        public static double CalculateFV(double principle)
        {
            double FV = 0;
            return FV;
        }
    }
}
