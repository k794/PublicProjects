﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Financial_Calculator
{
    class DataGridPopulator
    {
        public static void PopulateTables(ref DataGridView CurrentDataGrid, string[] row, string[] col, string tableHeader)
        {

            CurrentDataGrid.TopLeftHeaderCell.Value = tableHeader;


            int colNum = 0;
            foreach (var item in col)
            {
                CurrentDataGrid.Columns.Add(item, item);
                colNum++;
            }

            int rowNum = 0;
            foreach (var item in row)
            {
                CurrentDataGrid.Rows.Add();
                CurrentDataGrid.Rows[rowNum].HeaderCell.Value = item;
                rowNum++;
            }

            CurrentDataGrid.AllowUserToAddRows = false;            
        }
        public static void FormatTables (ref DataGridView CurrentDataGrid, int rHeight, int rHeaderWidth, int cWidth, int cHeaderHeight)
        {
            CurrentDataGrid.RowTemplate.Height = rHeight;
            CurrentDataGrid.RowHeadersWidth = rHeaderWidth;
            CurrentDataGrid.ColumnHeadersHeight = cHeaderHeight;


            for (int i = 0; CurrentDataGrid.ColumnCount > i; i++)
            {
                DataGridViewColumn column = CurrentDataGrid.Columns[i];
                column.SortMode = DataGridViewColumnSortMode.NotSortable;
                column.Width = cWidth;
            }
        }
        public static void TableProperties ( ref DataGridView CurrentDataGrid, bool rResize, bool cResize, bool rDelete, bool rAdd)
        {
            CurrentDataGrid.AllowUserToAddRows = rAdd;
            CurrentDataGrid.AllowUserToDeleteRows = rDelete;
            CurrentDataGrid.AllowUserToResizeRows = rResize;
            CurrentDataGrid.AllowUserToResizeColumns = cResize;
        }
    }
}
