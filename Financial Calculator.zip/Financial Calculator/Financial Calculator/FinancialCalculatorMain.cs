﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DGV = Financial_Calculator.DataGridPopulator;

namespace Financial_Calculator
{
    public partial class FinancialCalculatorMain : Form
    {
        public static string[] FutureValueRow =  {""};
        public static string[] FutureValueCol = { "Principle", "Payment", "Interest Rate", "Number of Periods", "Future Value" };

        public FinancialCalculatorMain()
        {
            InitializeComponent();
        }

        private void FinancialCalculatorMain_Load(object sender, EventArgs e)
        {

            DGV.PopulateTables(ref dgvFutureValue, FutureValueRow, FutureValueCol, "Future Value Calculator");
            DGV.FormatTables(ref dgvFutureValue, 150, 150, 80, 60);
            DGV.TableProperties(ref dgvFutureValue, false, true, false, false);
            dgvFutureValue.BorderStyle = BorderStyle.None;
            dgvFutureValue.BackgroundColor = FinancialCalculatorMain.DefaultBackColor;

        }

        private void dgvFutureValue_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (this.dgvFutureValue.Columns[e.ColumnIndex].Name == "Payment")
            {
                dgvFutureValue.Columns[e.ColumnIndex].DefaultCellStyle.Format = "c";
            }
        }

        private void dgvFutureValue_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //dgvFutureValue.Columns[1].DefaultCellStyle.Format = "c";
        }
    }
}
